"""
Unit tests for retrieval subsystem.
"""

import pytest
import asyncio
from datetime import datetime

from schemas import (
    CanonicalKnowledgeObject,
    KnowledgeType,
    RetrievalQuery,
    RetrievalResult,
    FusedResult,
)
from retrieval import (
    BM25Retriever,
    HybridFusion,
    QueryExpander,
    Reranker,
    RetrievalService,
)


class TestBM25Retriever:
    """Tests for BM25 lexical retrieval."""
    
    @pytest.mark.asyncio
    async def test_index_and_retrieve(self):
        """Test basic indexing and retrieval."""
        retriever = BM25Retriever()
        
        # Create test documents
        doc1 = CanonicalKnowledgeObject(
            tenant_id='test',
            source_id='src1',
            content_hash='hash1',
            content='Machine learning is a subset of artificial intelligence.',
            knowledge_type=KnowledgeType.DOCUMENT,
        )
        
        doc2 = CanonicalKnowledgeObject(
            tenant_id='test',
            source_id='src2',
            content_hash='hash2',
            content='Deep learning uses neural networks with many layers.',
            knowledge_type=KnowledgeType.DOCUMENT,
        )
        
        # Index documents
        await retriever.index_document(doc1)
        await retriever.index_document(doc2)
        
        assert retriever._total_docs == 2
        
        # Query
        query = RetrievalQuery(
            tenant_id='test',
            original_query='What is machine learning?',
        )
        
        results = await retriever.retrieve(query, limit=5)
        
        assert len(results) > 0
        assert results[0].retriever_type == 'bm25'
    
    @pytest.mark.asyncio
    async def test_tenant_isolation(self):
        """Test that tenant isolation works correctly."""
        retriever = BM25Retriever()
        
        # Documents from different tenants
        doc1 = CanonicalKnowledgeObject(
            tenant_id='tenant_a',
            source_id='src1',
            content_hash='hash1',
            content='Document for tenant A about machine learning.',
            knowledge_type=KnowledgeType.DOCUMENT,
        )
        
        doc2 = CanonicalKnowledgeObject(
            tenant_id='tenant_b',
            source_id='src2',
            content_hash='hash2',
            content='Document for tenant B about machine learning.',
            knowledge_type=KnowledgeType.DOCUMENT,
        )
        
        await retriever.index_document(doc1)
        await retriever.index_document(doc2)
        
        # Query from tenant_a should only see doc1
        query_a = RetrievalQuery(
            tenant_id='tenant_a',
            original_query='machine learning',
        )
        
        results_a = await retriever.retrieve(query_a, limit=5)
        
        assert len(results_a) == 1
        assert results_a[0].knowledge_object_id == doc1.id
    
    @pytest.mark.asyncio
    async def test_empty_results(self):
        """Test retrieval with no matching documents."""
        retriever = BM25Retriever()
        
        query = RetrievalQuery(
            tenant_id='empty',
            original_query='xyz123nonexistent',
        )
        
        results = await retriever.retrieve(query, limit=5)
        
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_health_check(self):
        """Test health check functionality."""
        retriever = BM25Retriever()
        
        healthy, message = await retriever.health_check()
        
        assert healthy is True
        assert 'BM25' in message


class TestHybridFusion:
    """Tests for hybrid fusion with RRF."""
    
    def test_fuse_single_retriever(self):
        """Test fusion with single retriever results."""
        fusion = HybridFusion()
        
        results = {
            'dense': [
                RetrievalResult(knowledge_object_id='doc1', score=0.9, rank=1, retriever_type='dense'),
                RetrievalResult(knowledge_object_id='doc2', score=0.7, rank=2, retriever_type='dense'),
            ]
        }
        
        fused = fusion.fuse(results, limit=5)
        
        assert len(fused) == 2
        assert fused[0].knowledge_object_id == 'doc1'
    
    def test_fuse_multiple_retrievers(self):
        """Test fusion with multiple retrievers."""
        fusion = HybridFusion()
        
        results = {
            'dense': [
                RetrievalResult(knowledge_object_id='doc1', score=0.9, rank=1, retriever_type='dense'),
                RetrievalResult(knowledge_object_id='doc2', score=0.7, rank=2, retriever_type='dense'),
            ],
            'bm25': [
                RetrievalResult(knowledge_object_id='doc2', score=0.8, rank=1, retriever_type='bm25'),
                RetrievalResult(knowledge_object_id='doc1', score=0.6, rank=2, retriever_type='bm25'),
            ]
        }
        
        fused = fusion.fuse(results, limit=5)
        
        # doc2 appears first in bm25 and second in dense
        # doc1 appears first in dense and second in bm25
        # Both should have same RRF score, order may vary
        assert len(fused) == 2
        assert set([f.knowledge_object_id for f in fused]) == {'doc1', 'doc2'}
    
    def test_fuse_limit(self):
        """Test that fusion respects limit parameter."""
        fusion = HybridFusion()
        
        results = {
            'dense': [
                RetrievalResult(knowledge_object_id=f'doc{i}', score=1.0-i*0.1, rank=i+1, retriever_type='dense')
                for i in range(10)
            ]
        }
        
        fused = fusion.fuse(results, limit=5)
        
        assert len(fused) == 5
    
    def test_weighted_scoring(self):
        """Test weighted scoring adjustment."""
        fusion = HybridFusion()
        
        results = {
            'dense': [
                RetrievalResult(knowledge_object_id='doc1', score=0.9, rank=1, retriever_type='dense'),
            ]
        }
        
        fused = fusion.fuse(results, limit=5)
        
        knowledge_objects = {
            'doc1': CanonicalKnowledgeObject(
                tenant_id='test',
                source_id='src1',
                content_hash='hash1',
                content='Test content',
                knowledge_type=KnowledgeType.DOCUMENT,
                authority_score=0.9,
            )
        }
        
        fused = fusion.apply_weighted_scoring(fused, knowledge_objects)
        
        # Score should be adjusted with authority signal
        assert fused[0].fused_score > fused[0].rrf_score


class TestQueryExpander:
    """Tests for query expansion."""
    
    def test_no_expansion_for_simple_query(self):
        """Test that simple queries are not expanded."""
        expander = QueryExpander()
        
        query = RetrievalQuery(
            tenant_id='test',
            original_query='Python documentation',
        )
        
        expanded = expander.expand(query, complexity=0.2)
        
        assert len(expanded.expanded_queries) == 0
    
    def test_expansion_for_complex_query(self):
        """Test that complex queries are expanded."""
        expander = QueryExpander()
        
        query = RetrievalQuery(
            tenant_id='test',
            original_query='What are the causes and effects?',
            entities=['causes', 'effects'],
        )
        
        expanded = expander.expand(query, complexity=0.7)
        
        assert len(expanded.expanded_queries) > 1
        assert query.original_query in expanded.expanded_queries
    
    def test_entity_expansion(self):
        """Test entity-based query expansion."""
        expander = QueryExpander()
        
        query = RetrievalQuery(
            tenant_id='test',
            original_query='Tell me about quantum computing',
            entities=['quantum computing', 'qubits'],
        )
        
        expanded = expander.expand(query, complexity=0.6)
        
        # Should include entity-focused queries
        assert any('quantum computing' in q for q in expanded.expanded_queries)


class TestReranker:
    """Tests for reranking functionality."""
    
    @pytest.mark.asyncio
    async def test_rerank_fallback(self):
        """Test that reranker falls back gracefully when unavailable."""
        reranker = Reranker()
        # Don't initialize - simulate unavailable model
        
        candidates = [
            FusedResult(knowledge_object_id='doc1', fused_score=0.9, rank=1, rrf_score=0.9),
            FusedResult(knowledge_object_id='doc2', fused_score=0.7, rank=2, rrf_score=0.7),
        ]
        
        knowledge_objects = {}
        
        reranked = await reranker.rerank('query', candidates, knowledge_objects, limit=5)
        
        # Should return top-k by initial score
        assert len(reranked) == 2
        assert reranked[0].fused_score >= reranked[1].fused_score


class TestRetrievalService:
    """Tests for main retrieval service."""
    
    @pytest.mark.asyncio
    async def test_service_initialization(self):
        """Test service initialization."""
        bm25 = BM25Retriever()
        
        service = RetrievalService(bm25_retriever=bm25)
        
        await service.initialize()
        
        assert service._bm25 is not None
    
    @pytest.mark.asyncio
    async def test_degraded_mode(self):
        """Test degraded mode when retrievers fail."""
        service = RetrievalService()
        # No retrievers configured
        
        from schemas import QueryAnalysis, IntentType, ExecutionLevel
        
        query = RetrievalQuery(
            tenant_id='test',
            original_query='test query',
        )
        
        query_analysis = QueryAnalysis(
            intent=IntentType.LOOKUP,
            domain='general',
            execution_level=ExecutionLevel.L1,
        )
        
        results = await service.retrieve(query, query_analysis, {})
        
        assert len(results) == 0
        assert service.is_degraded is True
    
    @pytest.mark.asyncio
    async def test_health_check(self):
        """Test service health check."""
        bm25 = BM25Retriever()
        service = RetrievalService(bm25_retriever=bm25)
        
        health = await service.health_check()
        
        assert 'bm25' in health
        assert health['bm25'][0] is True


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
