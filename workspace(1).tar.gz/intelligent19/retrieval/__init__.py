"""
Retrieval subsystem for INTELLIGENT19 V5.

Implements adaptive retrieval with:
- Multiple retriever types (dense, lexical, graph, memory, SQL)
- Hybrid fusion (RRF + weighted scoring)
- Query expansion
- Reranking
- Graceful degradation
"""

from __future__ import annotations
import asyncio
import time
from abc import ABC, abstractmethod
from typing import Any, Optional, Protocol
from dataclasses import dataclass, field

from schemas import (
    RetrievalQuery,
    RetrievalResult,
    FusedResult,
    CanonicalKnowledgeObject,
    ExecutionLevel,
)
from config.settings import Config, get_default_config


# ============================================================================
# RETRIEVER INTERFACE
# ============================================================================

class Retriever(Protocol):
    """
    Protocol for all retrievers.
    
    All retriever implementations must follow this interface.
    """
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        limit: int,
    ) -> list[RetrievalResult]:
        """
        Retrieve relevant knowledge objects for a query.
        
        Args:
            query: Normalized retrieval query
            limit: Maximum number of results to return
            
        Returns:
            List of retrieval results with scores
        """
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check if retriever is healthy."""
        ...


# ============================================================================
# DENSE RETRIEVER
# ============================================================================

class DenseRetriever:
    """
    Dense vector retrieval using semantic embeddings.
    
    Falls back gracefully if vector store is unavailable.
    """
    
    def __init__(
        self,
        vector_store: Any,  # VectorStore protocol
        config: Optional[Config] = None,
    ):
        self._vector_store = vector_store
        self._config = config or get_default_config()
        self._embedding_model = None
        self._is_available = True
    
    async def initialize(self) -> None:
        """Initialize embedding model and vector store connection."""
        if self._vector_store:
            await self._vector_store.connect()
        
        # Lazy load embedding model
        try:
            from sentence_transformers import SentenceTransformer
            model_name = self._config.retrieval.embedding_model
            self._embedding_model = SentenceTransformer(model_name)
        except Exception as e:
            self._embedding_model = None
            self._is_available = False
    
    def _compute_embedding(self, text: str) -> list[float]:
        """Compute embedding for text."""
        if not self._embedding_model:
            raise RuntimeError("Embedding model not initialized")
        
        embeddings = self._embedding_model.encode(
            [text],
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return embeddings[0].tolist()
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        limit: int,
    ) -> list[RetrievalResult]:
        """Retrieve using dense vectors."""
        if not self._is_available or not self._vector_store:
            return []
        
        try:
            query_embedding = self._compute_embedding(query.original_query)
            
            results = await self._vector_store.search(
                query_embedding=query_embedding,
                limit=limit,
                tenant_id=query.tenant_id,
                filters=query.filters,
            )
            
            return results
        except Exception as e:
            # Graceful degradation - return empty results instead of crashing
            self._is_available = False
            return []
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check dense retriever health."""
        if not self._is_available:
            return (False, "Dense retriever not available")
        
        if self._vector_store:
            return await self._vector_store.health_check()
        
        return (True, "No vector store configured, but retriever is ready")


# ============================================================================
# LEXICAL RETRIEVER (BM25)
# ============================================================================

class BM25Retriever:
    """
    BM25 lexical retrieval.
    
    Works without external dependencies - pure Python implementation.
    """
    
    def __init__(
        self,
        lexical_store: Any = None,  # LexicalStore protocol
        config: Optional[Config] = None,
    ):
        self._lexical_store = lexical_store
        self._config = config or get_default_config()
        self._index: dict[str, dict[str, Any]] = {}  # In-memory fallback
        self._doc_lengths: dict[str, int] = {}
        self._avg_doc_length: float = 0.0
        self._idf: dict[str, float] = {}
        self._total_docs: int = 0
    
    async def index_document(
        self,
        knowledge_object: CanonicalKnowledgeObject,
    ) -> None:
        """Index a document for BM25 retrieval."""
        doc_id = knowledge_object.id
        content = knowledge_object.content
        
        # Simple tokenization
        tokens = content.lower().split()
        
        self._index[doc_id] = {
            'tokens': tokens,
            'token_counts': self._count_tokens(tokens),
            'content': content,
            'knowledge_object': knowledge_object,
        }
        
        self._doc_lengths[doc_id] = len(tokens)
        self._total_docs = len(self._index)
        
        # Update average document length
        total_length = sum(self._doc_lengths.values())
        self._avg_doc_length = total_length / max(self._total_docs, 1)
        
        # Update IDF
        for token in set(tokens):
            doc_count = sum(
                1 for doc in self._index.values()
                if token in doc['token_counts']
            )
            self._idf[token] = self._calculate_idf(doc_count, self._total_docs)
    
    def _count_tokens(self, tokens: list[str]) -> dict[str, int]:
        """Count token frequencies."""
        counts: dict[str, int] = {}
        for token in tokens:
            counts[token] = counts.get(token, 0) + 1
        return counts
    
    def _calculate_idf(self, doc_count: int, total_docs: int) -> float:
        """Calculate IDF score."""
        import math
        return math.log((total_docs - doc_count + 0.5) / (doc_count + 0.5) + 1)
    
    def _bm25_score(
        self,
        query_tokens: list[str],
        doc_tokens: dict[str, int],
        doc_length: int,
    ) -> float:
        """Calculate BM25 score for a document."""
        k1 = 1.5  # Term frequency scaling
        b = 0.75  # Length normalization
        
        score = 0.0
        doc_length_norm = 1 - b + b * (doc_length / max(self._avg_doc_length, 1))
        
        for token in query_tokens:
            if token in doc_tokens:
                tf = doc_tokens[token]
                idf = self._idf.get(token, 0.0)
                
                numerator = tf * (k1 + 1)
                denominator = tf + k1 * doc_length_norm
                
                score += idf * (numerator / denominator)
        
        return score
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        limit: int,
    ) -> list[RetrievalResult]:
        """Retrieve using BM25."""
        query_tokens = query.original_query.lower().split()
        
        scores: list[tuple[str, float]] = []
        
        for doc_id, doc_data in self._index.items():
            # Tenant isolation
            ko = doc_data['knowledge_object']
            if ko.tenant_id != query.tenant_id:
                continue
            
            score = self._bm25_score(
                query_tokens,
                doc_data['token_counts'],
                self._doc_lengths.get(doc_id, 0),
            )
            
            if score > 0:
                scores.append((doc_id, score))
        
        # Sort by score descending
        scores.sort(key=lambda x: x[1], reverse=True)
        
        # Create results
        results: list[RetrievalResult] = []
        for rank, (doc_id, score) in enumerate(scores[:limit]):
            results.append(RetrievalResult(
                knowledge_object_id=doc_id,
                score=score,
                rank=rank + 1,
                retriever_type='bm25',
            ))
        
        return results
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check BM25 retriever health."""
        return (True, f"BM25 index contains {self._total_docs} documents")


# ============================================================================
# GRAPH RETRIEVER
# ============================================================================

class GraphRetriever:
    """
    Graph-based retrieval using knowledge graph traversal.
    
    Falls back to empty results if graph DB is unavailable.
    """
    
    def __init__(
        self,
        graph_store: Any = None,  # GraphStore protocol
        config: Optional[Config] = None,
    ):
        self._graph_store = graph_store
        self._config = config or get_default_config()
        self._is_available = graph_store is not None
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        limit: int,
    ) -> list[RetrievalResult]:
        """Retrieve using graph traversal."""
        if not self._is_available or not self._graph_store:
            return []
        
        try:
            # Extract entities from query
            entities = query.entities or []
            
            if not entities:
                return []
            
            results: list[RetrievalResult] = []
            
            for entity in entities[:5]:  # Limit entity count
                # Query graph for related nodes
                cypher = """
                MATCH (e:Entity {name: $entity})<-[:MENTIONS]-(ko)
                WHERE ko.tenant_id = $tenant_id
                RETURN ko.id as id, count(*) as relevance
                ORDER BY relevance DESC
                LIMIT $limit
                """
                
                graph_results = await self._graph_store.query(
                    cypher=cypher,
                    parameters={
                        'entity': entity,
                        'tenant_id': query.tenant_id,
                        'limit': limit // len(entities),
                    },
                    tenant_id=query.tenant_id,
                )
                
                for result in graph_results:
                    results.append(RetrievalResult(
                        knowledge_object_id=result['id'],
                        score=result['relevance'] / 10.0,  # Normalize
                        rank=len(results) + 1,
                        retriever_type='graph',
                    ))
            
            return results[:limit]
            
        except Exception as e:
            self._is_available = False
            return []
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check graph retriever health."""
        if not self._is_available:
            return (False, "Graph store not configured")
        
        if self._graph_store:
            return await self._graph_store.health_check()
        
        return (False, "Graph store connection failed")


# ============================================================================
# MEMORY RETRIEVER
# ============================================================================

class MemoryRetriever:
    """
    Retrieval from memory layers.
    
    Searches working, episodic, and semantic memory.
    """
    
    def __init__(
        self,
        memory_store: Any = None,  # MemoryStore protocol
        config: Optional[Config] = None,
    ):
        self._memory_store = memory_store
        self._config = config or get_default_config()
        self._is_available = memory_store is not None
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        limit: int,
    ) -> list[RetrievalResult]:
        """Retrieve from memory."""
        if not self._is_available or not self._memory_store:
            return []
        
        try:
            # Search by content similarity
            memories = await self._memory_store.search_by_content(
                query=query.original_query,
                tenant_id=query.tenant_id,
                limit=limit,
            )
            
            results: list[RetrievalResult] = []
            for memory in memories:
                # Calculate relevance based on importance and confidence
                score = memory.importance * memory.confidence
                
                results.append(RetrievalResult(
                    knowledge_object_id=memory.memory_id,
                    score=score,
                    rank=len(results) + 1,
                    retriever_type='memory',
                    metadata={
                        'memory_type': memory.memory_type.value,
                        'importance': memory.importance,
                        'confidence': memory.confidence,
                    },
                ))
            
            return results
            
        except Exception as e:
            self._is_available = False
            return []
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check memory retriever health."""
        if not self._is_available:
            return (False, "Memory store not configured")
        
        if self._memory_store:
            return await self._memory_store.health_check()
        
        return (False, "Memory store connection failed")


# ============================================================================
# HYBRID FUSION
# ============================================================================

class HybridFusion:
    """
    Hybrid fusion of multiple retrieval results.
    
    Uses Reciprocal Rank Fusion (RRF) combined with weighted scoring.
    """
    
    def __init__(self, config: Optional[Config] = None):
        self._config = config or get_default_config()
        self._rrf_k = self._config.retrieval.rrf_k
        self._semantic_weight = self._config.retrieval.semantic_weight
        self._lexical_weight = self._config.retrieval.lexical_weight
        self._authority_weight = self._config.retrieval.authority_weight
        self._freshness_weight = self._config.retrieval.freshness_weight
    
    def fuse(
        self,
        all_results: dict[str, list[RetrievalResult]],
        limit: int,
    ) -> list[FusedResult]:
        """
        Fuse results from multiple retrievers using RRF.
        
        Args:
            all_results: Dictionary mapping retriever type to results
            limit: Maximum number of fused results
            
        Returns:
            Fused and ranked results
        """
        # Collect all document IDs
        all_doc_ids: set[str] = set()
        for results in all_results.values():
            for result in results:
                all_doc_ids.add(result.knowledge_object_id)
        
        # Calculate RRF scores
        rrf_scores: dict[str, float] = {}
        component_scores: dict[str, dict[str, float]] = {}
        
        for doc_id in all_doc_ids:
            rrf_score = 0.0
            component_scores[doc_id] = {}
            
            for retriever_type, results in all_results.items():
                for rank, result in enumerate(results, start=1):
                    if result.knowledge_object_id == doc_id:
                        # RRF formula: 1 / (k + rank)
                        rrf_contribution = 1.0 / (self._rrf_k + rank)
                        rrf_score += rrf_contribution
                        component_scores[doc_id][retriever_type] = result.score
                        break
            
            rrf_scores[doc_id] = rrf_score
        
        # Sort by RRF score
        sorted_docs = sorted(
            rrf_scores.items(),
            key=lambda x: x[1],
            reverse=True,
        )
        
        # Create fused results
        fused_results: list[FusedResult] = []
        for rank, (doc_id, rrf_score) in enumerate(sorted_docs[:limit], start=1):
            fused_results.append(FusedResult(
                knowledge_object_id=doc_id,
                fused_score=rrf_score,
                rank=rank,
                component_scores=component_scores[doc_id],
                rrf_score=rrf_score,
            ))
        
        return fused_results
    
    def apply_weighted_scoring(
        self,
        fused_results: list[FusedResult],
        knowledge_objects: dict[str, CanonicalKnowledgeObject],
    ) -> list[FusedResult]:
        """
        Apply additional weighted scoring signals.
        
        Combines RRF with:
        - Semantic similarity
        - Authority score
        - Freshness
        """
        from datetime import datetime
        
        for result in fused_results:
            ko = knowledge_objects.get(result.knowledge_object_id)
            if not ko:
                continue
            
            # Authority signal
            authority_signal = ko.authority_score * self._authority_weight
            
            # Freshness signal
            freshness_signal = 0.0
            if ko.created_at:
                age_days = (datetime.utcnow() - ko.created_at).days
                freshness_signal = max(0, 1 - (age_days / 365)) * self._freshness_weight
            
            # Adjust fused score
            result.fused_score = (
                result.rrf_score +
                authority_signal +
                freshness_signal
            )
        
        # Re-sort by adjusted score
        fused_results.sort(key=lambda x: x.fused_score, reverse=True)
        
        # Update ranks
        for rank, result in enumerate(fused_results, start=1):
            result.rank = rank
        
        return fused_results


# ============================================================================
# QUERY EXPANSION
# ============================================================================

class QueryExpander:
    """
    Query expansion for complex queries.
    
    Generates sub-queries for parallel retrieval.
    """
    
    def __init__(self, config: Optional[Config] = None):
        self._config = config or get_default_config()
    
    def expand(
        self,
        query: RetrievalQuery,
        complexity: float,
    ) -> RetrievalQuery:
        """
        Expand query based on complexity.
        
        For simple queries, returns original.
        For complex queries, generates sub-queries.
        """
        if complexity < 0.3:
            # Simple query - no expansion needed
            return query
        
        # Rule-based expansion (no LLM dependency)
        expanded_queries = [query.original_query]
        
        # Add entity-focused queries
        for entity in query.entities[:3]:
            expanded_queries.append(f"{entity}")
        
        # Add keyword variations
        original_lower = query.original_query.lower()
        if "what" in original_lower:
            expanded_queries.append(original_lower.replace("what", "definition"))
        if "how" in original_lower:
            expanded_queries.append(original_lower.replace("how", "process"))
        if "why" in original_lower:
            expanded_queries.append(original_lower.replace("why", "reason"))
        
        # Remove duplicates while preserving order
        seen = set()
        unique_queries = []
        for q in expanded_queries:
            if q not in seen:
                seen.add(q)
                unique_queries.append(q)
        
        query.expanded_queries = unique_queries[:5]
        
        return query


# ============================================================================
# RERANKER
# ============================================================================

class Reranker:
    """
    Cross-encoder reranking for final candidate selection.
    
    Falls back to initial ranking if reranker unavailable.
    """
    
    def __init__(self, config: Optional[Config] = None):
        self._config = config or get_default_config()
        self._model = None
        self._is_available = False
    
    async def initialize(self) -> None:
        """Initialize reranker model."""
        try:
            from sentence_transformers import CrossEncoder
            self._model = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
            self._is_available = True
        except Exception:
            self._is_available = False
    
    async def rerank(
        self,
        query: str,
        candidates: list[FusedResult],
        knowledge_objects: dict[str, CanonicalKnowledgeObject],
        limit: int,
    ) -> list[FusedResult]:
        """Rerank candidates using cross-encoder."""
        if not self._is_available or not self._model or len(candidates) == 0:
            # Return top-k by initial score if reranker unavailable
            return sorted(candidates, key=lambda x: x.fused_score, reverse=True)[:limit]
        
        # Prepare pairs for reranking
        pairs = []
        for candidate in candidates:
            ko = knowledge_objects.get(candidate.knowledge_object_id)
            if ko:
                pairs.append([query, ko.content])
        
        if not pairs:
            return candidates[:limit]
        
        # Get rerank scores
        try:
            scores = self._model.predict(pairs)
            
            # Update candidates with rerank scores
            for i, candidate in enumerate(candidates):
                if i < len(scores):
                    candidate.fused_score = float(scores[i])
            
            # Sort by rerank score
            candidates.sort(key=lambda x: x.fused_score, reverse=True)
            
            # Update ranks
            for rank, candidate in enumerate(candidates[:limit], start=1):
                candidate.rank = rank
            
        except Exception:
            pass
        
        return candidates[:limit]


# ============================================================================
# RETRIEVAL ROUTER
# ============================================================================

class RetrievalRouter:
    """
    Routes queries to appropriate retrievers based on query analysis.
    
    Implements adaptive retrieval strategy.
    """
    
    def __init__(
        self,
        dense_retriever: Optional[DenseRetriever] = None,
        bm25_retriever: Optional[BM25Retriever] = None,
        graph_retriever: Optional[GraphRetriever] = None,
        memory_retriever: Optional[MemoryRetriever] = None,
        config: Optional[Config] = None,
    ):
        self._dense = dense_retriever
        self._bm25 = bm25_retriever
        self._graph = graph_retriever
        self._memory = memory_retriever
        self._config = config or get_default_config()
    
    def select_retrievers(
        self,
        query_analysis: Any,  # QueryAnalysis
    ) -> list[str]:
        """Select which retrievers to use based on query analysis."""
        retrievers = ['bm25']  # BM25 is always available as fallback
        
        if query_analysis.requires_graph and self._graph:
            retrievers.append('graph')
        
        if query_analysis.requires_memory and self._memory:
            retrievers.append('memory')
        
        # Dense retrieval for most queries unless exact match required
        if not query_analysis.requires_exact_match and self._dense:
            retrievers.append('dense')
        
        return retrievers


# ============================================================================
# MAIN RETRIEVAL SERVICE
# ============================================================================

class RetrievalService:
    """
    Main retrieval service coordinating all components.
    
    Implements graceful degradation and circuit breaker patterns.
    """
    
    def __init__(
        self,
        dense_retriever: Optional[DenseRetriever] = None,
        bm25_retriever: Optional[BM25Retriever] = None,
        graph_retriever: Optional[GraphRetriever] = None,
        memory_retriever: Optional[MemoryRetriever] = None,
        config: Optional[Config] = None,
    ):
        self._dense = dense_retriever
        self._bm25 = bm25_retriever
        self._graph = graph_retriever
        self._memory = memory_retriever
        self._fusion = HybridFusion(config)
        self._expander = QueryExpander(config)
        self._reranker = Reranker(config)
        self._config = config or get_default_config()
        self._degraded_mode = False
    
    async def initialize(self) -> None:
        """Initialize all components."""
        if self._dense:
            await self._dense.initialize()
        
        if self._reranker:
            await self._reranker.initialize()
    
    async def retrieve(
        self,
        query: RetrievalQuery,
        query_analysis: Any,  # QueryAnalysis
        knowledge_objects: dict[str, CanonicalKnowledgeObject],
    ) -> list[FusedResult]:
        """
        Execute retrieval pipeline.
        
        Pipeline:
        1. Query expansion (if complex)
        2. Parallel retrieval from selected retrievers
        3. Hybrid fusion
        4. Weighted scoring
        5. Reranking
        """
        start_time = time.time()
        
        # Expand query if needed
        if query_analysis.complexity > 0.3:
            query = self._expander.expand(query, query_analysis.complexity)
        
        # Select retrievers
        retrievers_to_use = []
        if self._dense and self._dense._is_available:
            retrievers_to_use.append(('dense', self._dense))
        if self._bm25:
            retrievers_to_use.append(('bm25', self._bm25))
        if self._graph and self._graph._is_available:
            retrievers_to_use.append(('graph', self._graph))
        if self._memory and self._memory._is_available:
            retrievers_to_use.append(('memory', self._memory))
        
        # If no retrievers available, return empty
        if not retrievers_to_use:
            self._degraded_mode = True
            return []
        
        # Execute retrievals in parallel
        all_results: dict[str, list[RetrievalResult]] = {}
        
        async def run_retriever(name: str, retriever):
            limit = self._config.retrieval.dense_top_k
            results = await retriever.retrieve(query, limit)
            return name, results
        
        tasks = [run_retriever(name, ret) for name, ret in retrievers_to_use]
        completed = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in completed:
            if isinstance(result, Exception):
                # Log error but continue with other retrievers
                self._degraded_mode = True
            else:
                name, results = result
                all_results[name] = results
        
        # Fuse results
        fused = self._fusion.fuse(
            all_results,
            limit=self._config.retrieval.fusion_top_k,
        )
        
        # Apply weighted scoring
        fused = self._fusion.apply_weighted_scoring(fused, knowledge_objects)
        
        # Rerank
        fused = await self._reranker.rerank(
            query.original_query,
            fused,
            knowledge_objects,
            limit=self._config.retrieval.rerank_top_k,
        )
        
        return fused
    
    @property
    def is_degraded(self) -> bool:
        """Check if service is in degraded mode."""
        return self._degraded_mode
    
    async def health_check(self) -> dict[str, tuple[bool, Optional[str]]]:
        """Check health of all retrievers."""
        results = {}
        
        if self._dense:
            results['dense'] = await self._dense.health_check()
        
        if self._bm25:
            results['bm25'] = await self._bm25.health_check()
        
        if self._graph:
            results['graph'] = await self._graph.health_check()
        
        if self._memory:
            results['memory'] = await self._memory.health_check()
        
        return results
