"""
Storage abstraction layer for INTELLIGENT19 V5.

Defines protocols/interfaces for all storage backends.
Concrete implementations (PostgreSQL, Qdrant, BM25, Graph, Redis) 
implement these protocols.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Optional, Protocol, TypeVar, Generic, AsyncIterator
from datetime import datetime

from schemas import (
    CanonicalKnowledgeObject,
    RetrievalResult,
    MemoryEntry,
    MemoryType,
)


T = TypeVar('T')


class VectorStore(Protocol):
    """
    Protocol for vector database operations.
    
    Implementations: Qdrant, Weaviate, Milvus, Pinecone, etc.
    """
    
    async def connect(self) -> None:
        """Establish connection to vector store."""
        ...
    
    async def disconnect(self) -> None:
        """Close connection to vector store."""
        ...
    
    async def upsert(
        self,
        knowledge_object: CanonicalKnowledgeObject,
        embedding: list[float],
    ) -> bool:
        """Insert or update a knowledge object with its embedding."""
        ...
    
    async def search(
        self,
        query_embedding: list[float],
        limit: int,
        tenant_id: str,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[RetrievalResult]:
        """Search for similar vectors with tenant isolation."""
        ...
    
    async def delete(
        self,
        knowledge_object_id: str,
        tenant_id: str,
    ) -> bool:
        """Delete a knowledge object."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of vector store. Returns (is_healthy, error_message)."""
        ...


class LexicalStore(Protocol):
    """
    Protocol for lexical/full-text search operations.
    
    Implementations: BM25, Elasticsearch, OpenSearch, etc.
    """
    
    async def connect(self) -> None:
        """Initialize lexical index."""
        ...
    
    async def disconnect(self) -> None:
        """Close lexical index."""
        ...
    
    async def index_document(
        self,
        knowledge_object: CanonicalKnowledgeObject,
    ) -> bool:
        """Index a document for lexical search."""
        ...
    
    async def search(
        self,
        query: str,
        limit: int,
        tenant_id: str,
        filters: Optional[dict[str, Any]] = None,
    ) -> list[RetrievalResult]:
        """Search using lexical matching with tenant isolation."""
        ...
    
    async def delete(
        self,
        knowledge_object_id: str,
        tenant_id: str,
    ) -> bool:
        """Remove a document from the index."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of lexical store."""
        ...


class GraphStore(Protocol):
    """
    Protocol for graph database operations.
    
    Implementations: Neo4j, Neptune, JanusGraph, etc.
    """
    
    async def connect(self) -> None:
        """Establish connection to graph database."""
        ...
    
    async def disconnect(self) -> None:
        """Close connection to graph database."""
        ...
    
    async def create_node(
        self,
        node_type: str,
        properties: dict[str, Any],
        tenant_id: str,
    ) -> str:
        """Create a node in the graph. Returns node ID."""
        ...
    
    async def create_relationship(
        self,
        from_node_id: str,
        to_node_id: str,
        relationship_type: str,
        properties: Optional[dict[str, Any]] = None,
        tenant_id: str = "",
    ) -> bool:
        """Create a relationship between nodes."""
        ...
    
    async def traverse(
        self,
        start_node_id: str,
        relationship_types: Optional[list[str]] = None,
        max_depth: int = 3,
        tenant_id: str = "",
    ) -> list[dict[str, Any]]:
        """Traverse graph from a starting node."""
        ...
    
    async def query(
        self,
        cypher: str,
        parameters: Optional[dict[str, Any]] = None,
        tenant_id: str = "",
    ) -> list[dict[str, Any]]:
        """Execute a graph query with tenant isolation."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of graph store."""
        ...


class MetadataStore(Protocol):
    """
    Protocol for relational metadata storage.
    
    Implementations: PostgreSQL, MySQL, etc.
    """
    
    async def connect(self) -> None:
        """Establish database connection."""
        ...
    
    async def disconnect(self) -> None:
        """Close database connection."""
        ...
    
    async def save_knowledge_object(
        self,
        knowledge_object: CanonicalKnowledgeObject,
    ) -> bool:
        """Save a canonical knowledge object."""
        ...
    
    async def get_knowledge_object(
        self,
        knowledge_object_id: str,
        tenant_id: str,
    ) -> Optional[CanonicalKnowledgeObject]:
        """Retrieve a knowledge object by ID with tenant isolation."""
        ...
    
    async def query_knowledge_objects(
        self,
        tenant_id: str,
        filters: Optional[dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[CanonicalKnowledgeObject]:
        """Query knowledge objects with filters and pagination."""
        ...
    
    async def update_knowledge_object(
        self,
        knowledge_object: CanonicalKnowledgeObject,
    ) -> bool:
        """Update an existing knowledge object."""
        ...
    
    async def delete_knowledge_object(
        self,
        knowledge_object_id: str,
        tenant_id: str,
    ) -> bool:
        """Delete a knowledge object."""
        ...
    
    async def execute_query(
        self,
        query: str,
        parameters: Optional[dict[str, Any]] = None,
        tenant_id: str = "",
    ) -> list[dict[str, Any]]:
        """Execute a SQL query with tenant isolation."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of metadata store."""
        ...


class MemoryStore(Protocol):
    """
    Protocol for memory storage operations.
    
    Implementations: Redis, in-memory, etc.
    """
    
    async def connect(self) -> None:
        """Initialize memory store connection."""
        ...
    
    async def disconnect(self) -> None:
        """Close memory store connection."""
        ...
    
    async def store(
        self,
        memory: MemoryEntry,
    ) -> bool:
        """Store a memory entry."""
        ...
    
    async def retrieve(
        self,
        memory_id: str,
        tenant_id: str,
    ) -> Optional[MemoryEntry]:
        """Retrieve a memory by ID with tenant isolation."""
        ...
    
    async def search_by_type(
        self,
        memory_type: MemoryType,
        tenant_id: str,
        limit: int = 50,
    ) -> list[MemoryEntry]:
        """Search memories by type."""
        ...
    
    async def search_by_content(
        self,
        query: str,
        tenant_id: str,
        memory_type: Optional[MemoryType] = None,
        limit: int = 50,
    ) -> list[MemoryEntry]:
        """Search memories by content similarity."""
        ...
    
    async def update(
        self,
        memory: MemoryEntry,
    ) -> bool:
        """Update an existing memory."""
        ...
    
    async def delete(
        self,
        memory_id: str,
        tenant_id: str,
    ) -> bool:
        """Delete a memory."""
        ...
    
    async def apply_decay(
        self,
        tenant_id: str,
        decay_rate: float,
    ) -> int:
        """Apply decay to memories. Returns number of updated memories."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of memory store."""
        ...


class CacheStore(Protocol):
    """
    Protocol for caching operations.
    
    Implementations: Redis, Memcached, in-memory LRU cache.
    """
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        ...
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: Optional[int] = None,
    ) -> bool:
        """Set value in cache with optional TTL."""
        ...
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        ...
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        ...
    
    async def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern. Returns count of deleted keys."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of cache store."""
        ...


class ObjectStore(Protocol):
    """
    Protocol for object/blob storage.
    
    Implementations: S3, GCS, Azure Blob, filesystem.
    """
    
    async def connect(self) -> None:
        """Initialize object store connection."""
        ...
    
    async def disconnect(self) -> None:
        """Close object store connection."""
        ...
    
    async def put(
        self,
        key: str,
        data: bytes,
        metadata: Optional[dict[str, Any]] = None,
    ) -> bool:
        """Store an object."""
        ...
    
    async def get(self, key: str) -> Optional[bytes]:
        """Retrieve an object."""
        ...
    
    async def delete(self, key: str) -> bool:
        """Delete an object."""
        ...
    
    async def exists(self, key: str) -> bool:
        """Check if object exists."""
        ...
    
    async def list_objects(
        self,
        prefix: str = "",
        tenant_id: str = "",
    ) -> list[str]:
        """List objects with optional prefix filtering."""
        ...
    
    async def health_check(self) -> tuple[bool, Optional[str]]:
        """Check health of object store."""
        ...


# ============================================================================
# Storage Manager - Coordinates all storage backends
# ============================================================================

class StorageManager:
    """
    Manages all storage backends and provides unified interface.
    
    Implements dependency inversion - business logic depends on protocols,
    not concrete implementations.
    """
    
    def __init__(
        self,
        vector_store: Optional[VectorStore] = None,
        lexical_store: Optional[LexicalStore] = None,
        graph_store: Optional[GraphStore] = None,
        metadata_store: Optional[MetadataStore] = None,
        memory_store: Optional[MemoryStore] = None,
        cache_store: Optional[CacheStore] = None,
        object_store: Optional[ObjectStore] = None,
    ):
        self._vector_store = vector_store
        self._lexical_store = lexical_store
        self._graph_store = graph_store
        self._metadata_store = metadata_store
        self._memory_store = memory_store
        self._cache_store = cache_store
        self._object_store = object_store
    
    @property
    def vector(self) -> Optional[VectorStore]:
        return self._vector_store
    
    @property
    def lexical(self) -> Optional[LexicalStore]:
        return self._lexical_store
    
    @property
    def graph(self) -> Optional[GraphStore]:
        return self._graph_store
    
    @property
    def metadata(self) -> Optional[MetadataStore]:
        return self._metadata_store
    
    @property
    def memory(self) -> Optional[MemoryStore]:
        return self._memory_store
    
    @property
    def cache(self) -> Optional[CacheStore]:
        return self._cache_store
    
    @property
    def objects(self) -> Optional[ObjectStore]:
        return self._object_store
    
    async def connect_all(self) -> None:
        """Connect all configured storage backends."""
        stores = [
            self._vector_store,
            self._lexical_store,
            self._graph_store,
            self._metadata_store,
            self._memory_store,
            self._cache_store,
            self._object_store,
        ]
        
        for store in stores:
            if store and hasattr(store, 'connect'):
                await store.connect()
    
    async def disconnect_all(self) -> None:
        """Disconnect all storage backends."""
        stores = [
            self._vector_store,
            self._lexical_store,
            self._graph_store,
            self._metadata_store,
            self._memory_store,
            self._cache_store,
            self._object_store,
        ]
        
        for store in stores:
            if store and hasattr(store, 'disconnect'):
                await store.disconnect()
    
    async def health_check(self) -> dict[str, tuple[bool, Optional[str]]]:
        """Check health of all storage backends."""
        results = {}
        
        store_names = {
            'vector': self._vector_store,
            'lexical': self._lexical_store,
            'graph': self._graph_store,
            'metadata': self._metadata_store,
            'memory': self._memory_store,
            'cache': self._cache_store,
            'objects': self._object_store,
        }
        
        for name, store in store_names.items():
            if store and hasattr(store, 'health_check'):
                results[name] = await store.health_check()
            else:
                results[name] = (False, "Not configured")
        
        return results
