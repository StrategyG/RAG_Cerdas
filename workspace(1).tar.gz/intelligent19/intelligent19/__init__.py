"""
INTELLIGENT19 - Institutional Cognitive RAG Platform

Production-grade modular knowledge reasoning system.
"""

__version__ = "0.1.0"
__author__ = "Intelligent19 Team"
