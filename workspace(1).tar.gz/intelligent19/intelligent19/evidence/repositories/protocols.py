"""
Repository protocols for Evidence subsystem.

These protocols define the interface between the service layer and persistence layer,
allowing different implementations (in-memory, PostgreSQL, GraphDB) to be swapped
without changing business logic.
"""

from __future__ import annotations

from typing import Any, Generic, Optional, Protocol, TypeVar

T = TypeVar("T")


class Repository(Protocol, Generic[T]):
    """Base repository protocol."""

    async def get(self, id: str) -> Optional[T]:
        """Get entity by ID."""
        ...

    async def list_all(self, limit: int = 100, offset: int = 0) -> list[T]:
        """List all entities with pagination."""
        ...

    async def save(self, entity: T) -> T:
        """Save/create or update entity."""
        ...

    async def delete(self, id: str) -> bool:
        """Delete entity by ID."""
        ...

    async def exists(self, id: str) -> bool:
        """Check if entity exists."""
        ...


class EvidenceRepository(Protocol):
    """Repository for evidence objects."""

    async def get(self, id: str) -> Optional[Any]:
        """Get evidence by ID."""
        ...

    async def list_by_source(self, source_id: str, tenant_id: str) -> list[Any]:
        """List evidence by source ID."""
        ...

    async def list_by_claim(self, claim_id: str, tenant_id: str) -> list[Any]:
        """List evidence linked to a claim."""
        ...

    async def save(self, evidence: Any) -> Any:
        """Save evidence."""
        ...

    async def delete(self, id: str, tenant_id: str) -> bool:
        """Delete evidence."""
        ...

    async def exists(self, id: str) -> bool:
        """Check if evidence exists."""
        ...

    async def count(self, tenant_id: str) -> int:
        """Count evidence for tenant."""
        ...


class ClaimRepository(Protocol):
    """Repository for claim objects."""

    async def get(self, claim_id: str) -> Optional[Any]:
        """Get claim by ID."""
        ...

    async def get_by_content_hash(
        self, content_hash: str, tenant_id: str
    ) -> Optional[Any]:
        """Get claim by normalized content hash (for deduplication)."""
        ...

    async def list_by_status(
        self, status: str, tenant_id: str, limit: int = 100
    ) -> list[Any]:
        """List claims by verification status."""
        ...

    async def save(self, claim: Any) -> Any:
        """Save claim."""
        ...

    async def delete(self, claim_id: str, tenant_id: str) -> bool:
        """Delete claim."""
        ...

    async def exists(self, claim_id: str) -> bool:
        """Check if claim exists."""
        ...

    async def add_verification_record(
        self, claim_id: str, record: dict[str, Any]
    ) -> None:
        """Add verification history record."""
        ...

    async def get_verification_history(
        self, claim_id: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get verification history for claim."""
        ...

    async def count(self, tenant_id: str) -> int:
        """Count claims for tenant."""
        ...


class ProvenanceRepository(Protocol):
    """Repository for provenance records."""

    async def get(self, provenance_id: str) -> Optional[Any]:
        """Get provenance record by ID."""
        ...

    async def get_chain(self, entity_id: str) -> list[Any]:
        """Get full provenance chain for an entity."""
        ...

    async def save(self, record: Any) -> Any:
        """Save provenance record."""
        ...

    async def add_event(
        self, provenance_id: str, event: dict[str, Any]
    ) -> None:
        """Add event to provenance chain."""
        ...

    async def list_by_entity(self, entity_id: str) -> list[Any]:
        """List provenance records for an entity."""
        ...

    async def count(self, tenant_id: str) -> int:
        """Count provenance records for tenant."""
        ...


class GraphRepository(Protocol):
    """Repository for evidence graph operations."""

    async def add_node(
        self,
        node_id: str,
        node_type: str,
        content: str,
        metadata: dict[str, Any],
        tenant_id: str,
    ) -> Any:
        """Add node to graph."""
        ...

    async def get_node(self, node_id: str) -> Optional[Any]:
        """Get node by ID."""
        ...

    async def remove_node(self, node_id: str, tenant_id: str) -> bool:
        """Remove node from graph."""
        ...

    async def add_edge(
        self,
        edge_id: str,
        source_node_id: str,
        target_node_id: str,
        relationship: Any,
        weight: float,
        metadata: dict[str, Any],
        tenant_id: str,
    ) -> Any:
        """Add directed edge to graph."""
        ...

    async def get_edge(self, edge_id: str) -> Optional[Any]:
        """Get edge by ID."""
        ...

    async def remove_edge(self, edge_id: str, tenant_id: str) -> bool:
        """Remove edge from graph."""
        ...

    async def get_edges_for_node(
        self, node_id: str, direction: str = "both"
    ) -> list[Any]:
        """Get edges connected to a node."""
        ...

    async def get_neighbors(
        self,
        node_id: str,
        relationship: Optional[Any] = None,
    ) -> list[Any]:
        """Get neighbor nodes."""
        ...

    async def has_directed_cycle(self) -> bool:
        """Check if graph has directed cycle using DFS."""
        ...

    async def get_subgraph(
        self, start_node_id: str, max_depth: int = 3
    ) -> dict[str, Any]:
        """Get subgraph starting from a node."""
        ...

    async def count_nodes(self, tenant_id: str) -> int:
        """Count nodes for tenant."""
        ...

    async def count_edges(self, tenant_id: str) -> int:
        """Count edges for tenant."""
        ...


class ContradictionRepository(Protocol):
    """Repository for contradiction records."""

    async def save(
        self, contradiction: Any, tenant_id: str
    ) -> Any:
        """Save contradiction detection result."""
        ...

    async def list_by_item(
        self, item_id: str, tenant_id: str, limit: int = 100
    ) -> list[Any]:
        """List contradictions involving an item."""
        ...

    async def count(self, tenant_id: str) -> int:
        """Count contradictions for tenant."""
        ...


__all__ = [
    "Repository",
    "EvidenceRepository",
    "ClaimRepository",
    "ProvenanceRepository",
    "GraphRepository",
    "ContradictionRepository",
]
