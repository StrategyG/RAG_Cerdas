"""Repository implementations for Evidence subsystem."""

from .protocols import (
    Repository,
    EvidenceRepository,
    ClaimRepository,
    ProvenanceRepository,
    GraphRepository,
    ContradictionRepository,
)
from .in_memory import (
    InMemoryEvidenceRepository,
    InMemoryClaimRepository,
    InMemoryProvenanceRepository,
    InMemoryGraphRepository,
    InMemoryContradictionRepository,
)

__all__ = [
    # Protocols
    "Repository",
    "EvidenceRepository",
    "ClaimRepository",
    "ProvenanceRepository",
    "GraphRepository",
    "ContradictionRepository",
    # In-memory implementations
    "InMemoryEvidenceRepository",
    "InMemoryClaimRepository",
    "InMemoryProvenanceRepository",
    "InMemoryGraphRepository",
    "InMemoryContradictionRepository",
]
