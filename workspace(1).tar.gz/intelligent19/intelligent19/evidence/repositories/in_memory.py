"""In-memory repository implementations for testing."""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any, Optional

from ..repositories.protocols import (
    ClaimRepository,
    ContradictionRepository,
    EvidenceRepository,
    GraphRepository,
    ProvenanceRepository,
)


class InMemoryEvidenceRepository:
    """In-memory implementation of EvidenceRepository for testing."""

    def __init__(self):
        self._storage: dict[str, Any] = {}
        self._by_source: dict[str, set[str]] = {}
        self._by_claim: dict[str, set[str]] = {}
        self._by_tenant: dict[str, set[str]] = {}

    async def get(self, id: str) -> Optional[Any]:
        """Get evidence by ID."""
        return self._storage.get(id)

    async def list_by_source(
        self, source_id: str, tenant_id: str
    ) -> list[Any]:
        """List evidence by source ID."""
        evidence_ids = self._by_source.get(source_id, set())
        return [
            self._storage[eid]
            for eid in evidence_ids
            if eid in self._storage
        ]

    async def list_by_claim(
        self, claim_id: str, tenant_id: str
    ) -> list[Any]:
        """List evidence linked to a claim."""
        evidence_ids = self._by_claim.get(claim_id, set())
        return [
            self._storage[eid]
            for eid in evidence_ids
            if eid in self._storage
        ]

    async def save(self, evidence: Any) -> Any:
        """Save evidence."""
        from intelligent19.schemas.evidence import Evidence

        # Ensure tenant_id is set
        if not hasattr(evidence, "tenant_id") or not evidence.tenant_id:
            evidence.tenant_id = "default"

        self._storage[evidence.id] = evidence

        # Index by source
        if evidence.source_id not in self._by_source:
            self._by_source[evidence.source_id] = set()
        self._by_source[evidence.source_id].add(evidence.id)

        # Index by tenant
        if evidence.tenant_id not in self._by_tenant:
            self._by_tenant[evidence.tenant_id] = set()
        self._by_tenant[evidence.tenant_id].add(evidence.id)

        return evidence

    async def delete(self, id: str, tenant_id: str) -> bool:
        """Delete evidence."""
        if id not in self._storage:
            return False

        evidence = self._storage[id]

        # Remove from indexes
        if evidence.source_id in self._by_source:
            self._by_source[evidence.source_id].discard(id)

        if evidence.tenant_id in self._by_tenant:
            self._by_tenant[evidence.tenant_id].discard(id)

        del self._storage[id]
        return True

    async def exists(self, id: str) -> bool:
        """Check if evidence exists."""
        return id in self._storage

    async def count(self, tenant_id: str) -> int:
        """Count evidence for tenant."""
        return len(self._by_tenant.get(tenant_id, set()))


class InMemoryClaimRepository:
    """In-memory implementation of ClaimRepository for testing."""

    def __init__(self):
        self._storage: dict[str, Any] = {}
        self._by_hash: dict[str, str] = {}  # hash -> claim_id
        self._by_status: dict[str, set[str]] = {}
        self._by_tenant: dict[str, set[str]] = {}
        self._verification_history: dict[str, list[dict[str, Any]]] = {}

    def _compute_content_hash(
        self, text: str, claim_type: str, tenant_id: str
    ) -> str:
        """Compute normalized content hash for deduplication."""
        normalized = f"{tenant_id}:{claim_type}:{text.strip().lower()}"
        return hashlib.sha256(normalized.encode()).hexdigest()[:32]

    async def get(self, claim_id: str) -> Optional[Any]:
        """Get claim by ID."""
        return self._storage.get(claim_id)

    async def get_by_content_hash(
        self, content_hash: str, tenant_id: str
    ) -> Optional[Any]:
        """Get claim by normalized content hash."""
        claim_id = self._by_hash.get(content_hash)
        if claim_id and claim_id in self._storage:
            claim = self._storage[claim_id]
            if getattr(claim, "tenant_id", None) == tenant_id:
                return claim
        return None

    async def list_by_status(
        self, status: str, tenant_id: str, limit: int = 100
    ) -> list[Any]:
        """List claims by verification status."""
        claim_ids = self._by_status.get(status, set())
        result = []
        for cid in claim_ids:
            if cid in self._storage:
                claim = self._storage[cid]
                if getattr(claim, "tenant_id", None) == tenant_id:
                    result.append(claim)
                    if len(result) >= limit:
                        break
        return result

    async def save(self, claim: Any) -> Any:
        """Save claim with deduplication."""
        from intelligent19.schemas.evidence import Claim

        # Ensure tenant_id is set
        if not hasattr(claim, "tenant_id") or not claim.tenant_id:
            claim.tenant_id = "default"

        # Compute content hash for deduplication
        content_hash = self._compute_content_hash(
            claim.text, claim.claim_type, claim.tenant_id
        )

        # Check for existing claim with same content
        existing_id = self._by_hash.get(content_hash)
        if existing_id and existing_id in self._storage:
            existing = self._storage[existing_id]
            # Update existing claim's verification status if needed
            if hasattr(existing, "merge_verification"):
                existing.merge_verification(claim)
            return existing

        self._storage[claim.claim_id] = claim
        self._by_hash[content_hash] = claim.claim_id

        # Index by status
        status = claim.verification_status.value
        if status not in self._by_status:
            self._by_status[status] = set()
        self._by_status[status].add(claim.claim_id)

        # Index by tenant
        if claim.tenant_id not in self._by_tenant:
            self._by_tenant[claim.tenant_id] = set()
        self._by_tenant[claim.tenant_id].add(claim.claim_id)

        # Initialize verification history
        self._verification_history[claim.claim_id] = []

        return claim

    async def delete(self, claim_id: str, tenant_id: str) -> bool:
        """Delete claim."""
        if claim_id not in self._storage:
            return False

        claim = self._storage[claim_id]

        # Remove from indexes
        status = claim.verification_status.value
        if status in self._by_status:
            self._by_status[status].discard(claim_id)

        if claim.tenant_id in self._by_tenant:
            self._by_tenant[claim.tenant_id].discard(claim_id)

        # Remove from hash index
        content_hash = self._compute_content_hash(
            claim.text, claim.claim_type, claim.tenant_id
        )
        if self._by_hash.get(content_hash) == claim_id:
            del self._by_hash[content_hash]

        del self._storage[claim_id]
        self._verification_history.pop(claim_id, None)
        return True

    async def exists(self, claim_id: str) -> bool:
        """Check if claim exists."""
        return claim_id in self._storage

    async def add_verification_record(
        self, claim_id: str, record: dict[str, Any]
    ) -> None:
        """Add verification history record."""
        if claim_id not in self._verification_history:
            self._verification_history[claim_id] = []

        record_with_timestamp = {
            **record,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._verification_history[claim_id].append(record_with_timestamp)

    async def get_verification_history(
        self, claim_id: str, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get verification history for claim."""
        history = self._verification_history.get(claim_id, [])
        return history[-limit:]

    async def count(self, tenant_id: str) -> int:
        """Count claims for tenant."""
        return len(self._by_tenant.get(tenant_id, set()))


class InMemoryProvenanceRepository:
    """In-memory implementation of ProvenanceRepository for testing."""

    def __init__(self):
        self._storage: dict[str, Any] = {}
        self._by_entity: dict[str, set[str]] = {}
        self._by_tenant: dict[str, set[str]] = {}
        self._events: dict[str, list[dict[str, Any]]] = {}

    async def get(self, provenance_id: str) -> Optional[Any]:
        """Get provenance record by ID."""
        return self._storage.get(provenance_id)

    async def get_chain(self, entity_id: str) -> list[Any]:
        """Get full provenance chain for an entity."""
        provenance_ids = self._by_entity.get(entity_id, set())
        return [
            self._storage[pid]
            for pid in sorted(provenance_ids)
            if pid in self._storage
        ]

    async def save(self, record: Any) -> Any:
        """Save provenance record."""
        self._storage[record.provenance_id] = record

        # Index by entity
        entity_id = record.entity_id
        if entity_id not in self._by_entity:
            self._by_entity[entity_id] = set()
        self._by_entity[entity_id].add(record.provenance_id)

        # Index by tenant
        tenant_id = getattr(record, "tenant_id", "default")
        if tenant_id not in self._by_tenant:
            self._by_tenant[tenant_id] = set()
        self._by_tenant[tenant_id].add(record.provenance_id)

        # Initialize events
        self._events[record.provenance_id] = []

        return record

    async def add_event(
        self, provenance_id: str, event: dict[str, Any]
    ) -> None:
        """Add event to provenance chain."""
        if provenance_id not in self._events:
            self._events[provenance_id] = []

        event_with_timestamp = {
            **event,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._events[provenance_id].append(event_with_timestamp)

    async def list_by_entity(self, entity_id: str) -> list[Any]:
        """List provenance records for an entity."""
        provenance_ids = self._by_entity.get(entity_id, set())
        return [
            self._storage[pid]
            for pid in provenance_ids
            if pid in self._storage
        ]

    async def count(self, tenant_id: str) -> int:
        """Count provenance records for tenant."""
        return len(self._by_tenant.get(tenant_id, set()))


class InMemoryGraphRepository:
    """In-memory implementation of GraphRepository for testing."""

    def __init__(self):
        self._nodes: dict[str, Any] = {}
        self._edges: dict[str, Any] = {}
        self._outgoing: dict[str, set[str]] = {}  # node_id -> edge_ids
        self._incoming: dict[str, set[str]] = {}  # node_id -> edge_ids
        self._by_tenant: dict[str, set[str]] = {}  # tenant_id -> node_ids

    async def add_node(
        self,
        node_id: str,
        node_type: str,
        content: str,
        metadata: dict[str, Any],
        tenant_id: str,
    ) -> Any:
        """Add node to graph."""
        from intelligent19.evidence.graph.models import GraphNode, GraphNodeType

        node = GraphNode(
            node_id=node_id,
            node_type=GraphNodeType(node_type),
            content=content,
            metadata={**metadata, "tenant_id": tenant_id},
        )
        self._nodes[node_id] = node
        self._outgoing[node_id] = set()
        self._incoming[node_id] = set()

        if tenant_id not in self._by_tenant:
            self._by_tenant[tenant_id] = set()
        self._by_tenant[tenant_id].add(node_id)

        return node

    async def get_node(self, node_id: str) -> Optional[Any]:
        """Get node by ID."""
        return self._nodes.get(node_id)

    async def remove_node(self, node_id: str, tenant_id: str) -> bool:
        """Remove node from graph."""
        if node_id not in self._nodes:
            return False

        # Remove all connected edges
        edges_to_remove = list(
            self._outgoing.get(node_id, set())
            | self._incoming.get(node_id, set())
        )
        for edge_id in edges_to_remove:
            await self.remove_edge(edge_id, tenant_id)

        del self._nodes[node_id]
        self._outgoing.pop(node_id, None)
        self._incoming.pop(node_id, None)

        if tenant_id in self._by_tenant:
            self._by_tenant[tenant_id].discard(node_id)

        return True

    async def add_edge(
        self,
        edge_id: str,
        source_node_id: str,
        target_node_id: str,
        relationship: Any,
        weight: float,
        metadata: dict[str, Any],
        tenant_id: str,
    ) -> Any:
        """Add directed edge to graph."""
        from intelligent19.evidence.graph.models import GraphEdge

        edge = GraphEdge(
            edge_id=edge_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            relationship=relationship,
            weight=weight,
            metadata={**metadata, "tenant_id": tenant_id},
        )
        self._edges[edge_id] = edge

        # Track directed edges
        if source_node_id not in self._outgoing:
            self._outgoing[source_node_id] = set()
        self._outgoing[source_node_id].add(edge_id)

        if target_node_id not in self._incoming:
            self._incoming[target_node_id] = set()
        self._incoming[target_node_id].add(edge_id)

        return edge

    async def get_edge(self, edge_id: str) -> Optional[Any]:
        """Get edge by ID."""
        return self._edges.get(edge_id)

    async def remove_edge(self, edge_id: str, tenant_id: str) -> bool:
        """Remove edge from graph."""
        if edge_id not in self._edges:
            return False

        edge = self._edges[edge_id]

        self._outgoing[edge.source_node_id].discard(edge_id)
        self._incoming[edge.target_node_id].discard(edge_id)

        del self._edges[edge_id]
        return True

    async def get_edges_for_node(
        self, node_id: str, direction: str = "both"
    ) -> list[Any]:
        """Get edges connected to a node."""
        edges = []

        if direction in ("outgoing", "both"):
            for edge_id in self._outgoing.get(node_id, set()):
                if edge_id in self._edges:
                    edges.append(self._edges[edge_id])

        if direction in ("incoming", "both"):
            for edge_id in self._incoming.get(node_id, set()):
                if edge_id in self._edges:
                    edges.append(self._edges[edge_id])

        return edges

    async def get_neighbors(
        self,
        node_id: str,
        relationship: Optional[Any] = None,
    ) -> list[Any]:
        """Get neighbor nodes via outgoing edges."""
        neighbors = []
        for edge_id in self._outgoing.get(node_id, set()):
            if edge_id not in self._edges:
                continue

            edge = self._edges[edge_id]

            if relationship and edge.relationship != relationship:
                continue

            target_node = self._nodes.get(edge.target_node_id)
            if target_node:
                neighbors.append(target_node)

        return neighbors

    async def has_directed_cycle(self) -> bool:
        """Check if graph has directed cycle using DFS."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {node_id: WHITE for node_id in self._nodes}

        def dfs(node_id: str) -> bool:
            color[node_id] = GRAY

            for edge_id in self._outgoing.get(node_id, set()):
                if edge_id not in self._edges:
                    continue
                edge = self._edges[edge_id]
                neighbor = edge.target_node_id

                if color.get(neighbor, WHITE) == GRAY:
                    return True  # Back edge found - cycle!

                if color.get(neighbor, WHITE) == WHITE:
                    if dfs(neighbor):
                        return True

            color[node_id] = BLACK
            return False

        for node_id in self._nodes:
            if color[node_id] == WHITE:
                if dfs(node_id):
                    return True

        return False

    async def get_subgraph(
        self, start_node_id: str, max_depth: int = 3
    ) -> dict[str, Any]:
        """Get subgraph starting from a node using BFS."""
        from collections import deque

        if start_node_id not in self._nodes:
            return {"nodes": [], "edges": []}

        visited_nodes = {start_node_id}
        visited_edges = set()
        nodes = [self._nodes[start_node_id]]
        edges = []

        queue = deque([(start_node_id, 0)])

        while queue:
            node_id, depth = queue.popleft()

            if depth >= max_depth:
                continue

            for edge_id in self._outgoing.get(node_id, set()):
                if edge_id not in self._edges or edge_id in visited_edges:
                    continue

                edge = self._edges[edge_id]
                visited_edges.add(edge_id)
                edges.append(edge)

                if edge.target_node_id not in visited_nodes:
                    visited_nodes.add(edge.target_node_id)
                    if edge.target_node_id in self._nodes:
                        nodes.append(self._nodes[edge.target_node_id])
                    queue.append((edge.target_node_id, depth + 1))

        return {
            "nodes": [n.to_dict() for n in nodes],
            "edges": [e.to_dict() for e in edges],
        }

    async def count_nodes(self, tenant_id: str) -> int:
        """Count nodes for tenant."""
        return len(self._by_tenant.get(tenant_id, set()))

    async def count_edges(self, tenant_id: str) -> int:
        """Count edges for tenant."""
        # Count edges where both nodes belong to tenant
        tenant_nodes = self._by_tenant.get(tenant_id, set())
        count = 0
        for edge in self._edges.values():
            if (
                edge.source_node_id in tenant_nodes
                and edge.target_node_id in tenant_nodes
            ):
                count += 1
        return count


class InMemoryContradictionRepository:
    """In-memory implementation of ContradictionRepository for testing."""

    def __init__(self):
        self._storage: list[Any] = []
        self._by_item: dict[str, set[int]] = {}  # item_id -> indices
        self._by_tenant: dict[str, set[int]] = {}

    async def save(
        self, contradiction: Any, tenant_id: str
    ) -> Any:
        """Save contradiction detection result."""
        # Add tenant_id to contradiction
        contradiction.tenant_id = tenant_id

        idx = len(self._storage)
        self._storage.append(contradiction)

        # Index by items
        for item_id in [contradiction.item_a_id, contradiction.item_b_id]:
            if item_id not in self._by_item:
                self._by_item[item_id] = set()
            self._by_item[item_id].add(idx)

        # Index by tenant
        if tenant_id not in self._by_tenant:
            self._by_tenant[tenant_id] = set()
        self._by_tenant[tenant_id].add(idx)

        return contradiction

    async def list_by_item(
        self, item_id: str, tenant_id: str, limit: int = 100
    ) -> list[Any]:
        """List contradictions involving an item."""
        indices = self._by_item.get(item_id, set())
        result = []
        for idx in indices:
            if idx < len(self._storage):
                contradiction = self._storage[idx]
                if getattr(contradiction, "tenant_id", None) == tenant_id:
                    result.append(contradiction)
                    if len(result) >= limit:
                        break
        return result

    async def count(self, tenant_id: str) -> int:
        """Count contradictions for tenant."""
        return len(self._by_tenant.get(tenant_id, set()))


__all__ = [
    "InMemoryEvidenceRepository",
    "InMemoryClaimRepository",
    "InMemoryProvenanceRepository",
    "InMemoryGraphRepository",
    "InMemoryContradictionRepository",
]
