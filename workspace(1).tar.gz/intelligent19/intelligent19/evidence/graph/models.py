"""
Graph models for Evidence subsystem.

Implements directed graph with proper cycle detection and tenant isolation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class GraphNodeType(str, Enum):
    """Types of nodes in the evidence graph."""

    SOURCE = "source"
    DOCUMENT = "document"
    CHUNK = "chunk"
    EVIDENCE = "evidence"  # First-class evidence node
    FACT = "fact"
    CLAIM = "claim"
    ENTITY = "entity"
    EVENT = "event"
    DECISION = "decision"


class GraphRelationship(str, Enum):
    """
    Directed relationship types in evidence graph.
    
    These relationships are directional:
    - source -> target means source has relationship to target
    """

    # Support relationships (directed)
    SUPPORTS = "supports"  # A supports B
    CONTRADICTS = "contradicts"  # A contradicts B

    # Derivation relationships (directed)
    DERIVED_FROM = "derived_from"  # A derived from B
    FROM = "from"  # A from B (general origin)

    # Reference relationships (directed)
    MENTIONS = "mentions"  # A mentions B
    ABOUT = "about"  # A is about B

    # Temporal relationships (directed)
    VALID_DURING = "valid_during"  # A valid during period B
    SUPERSEDES = "supersedes"  # A supersedes B (A is newer)
    SUPERSEDED_BY = "superseded_by"  # A superseded by B

    # General relationships
    RELATED_TO = "related_to"  # A related to B (can be bidirectional)
    CAUSED_BY = "caused_by"  # A caused by B

    # Provenance relationships (directed)
    CREATED_FROM = "created_from"  # A created from B
    TRANSFORMED_TO = "transformed_to"  # A transformed to B


@dataclass
class GraphNode:
    """
    Node in the evidence graph.
    
    Attributes:
        node_id: Unique identifier
        node_type: Type of node
        content: Node content/text
        metadata: Additional metadata (includes tenant_id)
        created_at: Creation timestamp
    """

    node_id: str
    node_type: GraphNodeType
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def tenant_id(self) -> str:
        """Get tenant ID from metadata."""
        return self.metadata.get("tenant_id", "default")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "node_id": self.node_id,
            "node_type": self.node_type.value,
            "content": self.content,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "tenant_id": self.tenant_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GraphNode":
        """Create node from dictionary."""
        return cls(
            node_id=data["node_id"],
            node_type=GraphNodeType(data["node_type"]),
            content=data["content"],
            metadata=data.get("metadata", {}),
            created_at=(
                datetime.fromisoformat(data["created_at"])
                if "created_at" in data
                else datetime.now(timezone.utc)
            ),
        )


@dataclass
class GraphEdge:
    """
    Directed edge in the evidence graph representing a relationship.
    
    Attributes:
        edge_id: Unique identifier
        source_node_id: Source node ID (relationship originates here)
        target_node_id: Target node ID (relationship points here)
        relationship: Type of relationship
        weight: Edge weight/confidence
        metadata: Additional metadata
        created_at: Creation timestamp
    """

    edge_id: str
    source_node_id: str
    target_node_id: str
    relationship: GraphRelationship
    weight: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def tenant_id(self) -> str:
        """Get tenant ID from metadata."""
        return self.metadata.get("tenant_id", "default")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "edge_id": self.edge_id,
            "source_node_id": self.source_node_id,
            "target_node_id": self.target_node_id,
            "relationship": self.relationship.value,
            "weight": self.weight,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "tenant_id": self.tenant_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GraphEdge":
        """Create edge from dictionary."""
        return cls(
            edge_id=data["edge_id"],
            source_node_id=data["source_node_id"],
            target_node_id=data["target_node_id"],
            relationship=GraphRelationship(data["relationship"]),
            weight=data.get("weight", 1.0),
            metadata=data.get("metadata", {}),
            created_at=(
                datetime.fromisoformat(data["created_at"])
                if "created_at" in data
                else datetime.now(timezone.utc)
            ),
        )


@dataclass
class GraphPath:
    """Represents a path through the graph."""

    nodes: list[GraphNode]
    edges: list[GraphEdge]
    total_weight: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "total_weight": self.total_weight,
        }


__all__ = [
    "GraphNodeType",
    "GraphRelationship",
    "GraphNode",
    "GraphEdge",
    "GraphPath",
]
