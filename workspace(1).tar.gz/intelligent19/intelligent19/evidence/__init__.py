"""
Evidence subsystem for INTELLIGENT19 V5 - PHASE 2.

Implements:
- Evidence Graph with relationships
- Claim Ledger for tracking claims
- Provenance tracking
- Contradiction detection and resolution
- Temporal reasoning
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional, Protocol
from uuid import uuid4

# Import from root schemas module
from schemas import (
    CanonicalKnowledgeObject,
    Evidence,
    Claim,
    VerificationStatus as ClaimVerificationStatus,
    RelationshipType as EvidenceRelationship,
    Contradiction,
)


# ============================================================================
# EVIDENCE GRAPH
# ============================================================================

class GraphNodeType(str, Enum):
    """Types of nodes in the evidence graph."""
    SOURCE = "source"
    DOCUMENT = "document"
    CHUNK = "chunk"
    FACT = "fact"
    CLAIM = "claim"
    ENTITY = "entity"
    EVENT = "event"
    DECISION = "decision"


class GraphRelationship(str, Enum):
    """Relationship types in evidence graph."""
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    DERIVED_FROM = "derived_from"
    MENTIONS = "mentions"
    ABOUT = "about"
    VALID_DURING = "valid_during"
    SUPERSEDES = "supersedes"
    RELATED_TO = "related_to"
    CAUSED_BY = "caused_by"


@dataclass
class GraphNode:
    """Node in the evidence graph."""
    node_id: str
    node_type: GraphNodeType
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "node_id": self.node_id,
            "node_type": self.node_type.value,
            "content": self.content,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class GraphEdge:
    """Edge in the evidence graph representing a relationship."""
    edge_id: str
    source_node_id: str
    target_node_id: str
    relationship: GraphRelationship
    weight: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "edge_id": self.edge_id,
            "source_node_id": self.source_node_id,
            "target_node_id": self.target_node_id,
            "relationship": self.relationship.value,
            "weight": self.weight,
            "metadata": self.metadata,
        }


class EvidenceGraph:
    """
    Evidence graph for tracking relationships between evidence and claims.
    
    This is an in-memory implementation. Production should use a graph database.
    """
    
    def __init__(self):
        self._nodes: dict[str, GraphNode] = {}
        self._edges: dict[str, GraphEdge] = {}
        self._adjacency: dict[str, set[str]] = {}  # node_id -> neighbor edge_ids
    
    def add_node(
        self,
        node_id: str,
        node_type: GraphNodeType,
        content: str,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GraphNode:
        """Add a node to the graph."""
        node = GraphNode(
            node_id=node_id,
            node_type=node_type,
            content=content,
            metadata=metadata or {},
        )
        self._nodes[node_id] = node
        self._adjacency[node_id] = set()
        return node
    
    def remove_node(self, node_id: str) -> bool:
        """Remove a node and all its edges."""
        if node_id not in self._nodes:
            return False
        
        # Remove all edges connected to this node
        edges_to_remove = [
            edge_id for edge_id, edge in self._edges.items()
            if edge.source_node_id == node_id or edge.target_node_id == node_id
        ]
        
        for edge_id in edges_to_remove:
            self.remove_edge(edge_id)
        
        del self._nodes[node_id]
        del self._adjacency[node_id]
        return True
    
    def add_edge(
        self,
        edge_id: str,
        source_node_id: str,
        target_node_id: str,
        relationship: GraphRelationship,
        weight: float = 1.0,
        metadata: Optional[dict[str, Any]] = None,
    ) -> GraphEdge:
        """Add an edge to the graph."""
        if source_node_id not in self._nodes:
            raise ValueError(f"Source node {source_node_id} not found")
        if target_node_id not in self._nodes:
            raise ValueError(f"Target node {target_node_id} not found")
        
        edge = GraphEdge(
            edge_id=edge_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            relationship=relationship,
            weight=weight,
            metadata=metadata or {},
        )
        
        self._edges[edge_id] = edge
        self._adjacency[source_node_id].add(edge_id)
        self._adjacency[target_node_id].add(edge_id)
        
        return edge
    
    def remove_edge(self, edge_id: str) -> bool:
        """Remove an edge from the graph."""
        if edge_id not in self._edges:
            return False
        
        edge = self._edges[edge_id]
        self._adjacency[edge.source_node_id].discard(edge_id)
        self._adjacency[edge.target_node_id].discard(edge_id)
        del self._edges[edge_id]
        
        return True
    
    def get_node(self, node_id: str) -> Optional[GraphNode]:
        """Get a node by ID."""
        return self._nodes.get(node_id)
    
    def get_edges_for_node(self, node_id: str) -> list[GraphEdge]:
        """Get all edges connected to a node."""
        if node_id not in self._adjacency:
            return []
        
        return [
            self._edges[edge_id]
            for edge_id in self._adjacency[node_id]
            if edge_id in self._edges
        ]
    
    def find_neighbors(
        self,
        node_id: str,
        relationship: Optional[GraphRelationship] = None,
    ) -> list[GraphNode]:
        """Find neighboring nodes, optionally filtered by relationship type."""
        edges = self.get_edges_for_node(node_id)
        
        if relationship:
            edges = [e for e in edges if e.relationship == relationship]
        
        neighbors = []
        for edge in edges:
            neighbor_id = (
                edge.target_node_id
                if edge.source_node_id == node_id
                else edge.source_node_id
            )
            if neighbor_id in self._nodes:
                neighbors.append(self._nodes[neighbor_id])
        
        return neighbors
    
    def find_supporting_evidence(self, claim_node_id: str) -> list[GraphNode]:
        """Find all evidence nodes that support a claim."""
        return self.find_neighbors(claim_node_id, GraphRelationship.SUPPORTS)
    
    def find_contradicting_evidence(self, claim_node_id: str) -> list[GraphNode]:
        """Find all evidence nodes that contradict a claim."""
        return self.find_neighbors(claim_node_id, GraphRelationship.CONTRADICTS)
    
    def detect_cycles(self) -> list[list[str]]:
        """Detect cycles in the graph using DFS."""
        visited = set()
        rec_stack = set()
        cycles = []
        
        def dfs(node_id: str, path: list[str]) -> None:
            visited.add(node_id)
            rec_stack.add(node_id)
            path.append(node_id)
            
            for edge_id in self._adjacency.get(node_id, set()):
                edge = self._edges.get(edge_id)
                if not edge:
                    continue
                
                neighbor_id = (
                    edge.target_node_id
                    if edge.source_node_id == node_id
                    else edge.source_node_id
                )
                
                if neighbor_id not in visited:
                    dfs(neighbor_id, path.copy())
                elif neighbor_id in rec_stack:
                    # Found a cycle
                    cycle_start = path.index(neighbor_id)
                    cycles.append(path[cycle_start:] + [neighbor_id])
            
            rec_stack.remove(node_id)
        
        for node_id in self._nodes:
            if node_id not in visited:
                dfs(node_id, [])
        
        return cycles
    
    def get_subgraph_for_claim(self, claim_node_id: str, depth: int = 2) -> dict[str, Any]:
        """Extract subgraph around a claim node up to specified depth."""
        if claim_node_id not in self._nodes:
            return {"nodes": [], "edges": []}
        
        visited = {claim_node_id}
        current_layer = [claim_node_id]
        nodes_in_subgraph = {claim_node_id}
        edges_in_subgraph: set[str] = set()
        
        for _ in range(depth):
            next_layer = []
            for node_id in current_layer:
                for edge_id in self._adjacency.get(node_id, set()):
                    edge = self._edges.get(edge_id)
                    if not edge:
                        continue
                    
                    edges_in_subgraph.add(edge_id)
                    
                    neighbor_id = (
                        edge.target_node_id
                        if edge.source_node_id == node_id
                        else edge.source_node_id
                    )
                    
                    if neighbor_id not in visited:
                        visited.add(neighbor_id)
                        nodes_in_subgraph.add(neighbor_id)
                        next_layer.append(neighbor_id)
            
            current_layer = next_layer
        
        return {
            "nodes": [
                self._nodes[nid].to_dict()
                for nid in nodes_in_subgraph
                if nid in self._nodes
            ],
            "edges": [
                self._edges[eid].to_dict()
                for eid in edges_in_subgraph
                if eid in self._edges
            ],
        }
    
    def statistics(self) -> dict[str, Any]:
        """Get graph statistics."""
        node_types: dict[str, int] = {}
        relationship_types: dict[str, int] = {}
        
        for node in self._nodes.values():
            nt = node.node_type.value
            node_types[nt] = node_types.get(nt, 0) + 1
        
        for edge in self._edges.values():
            rt = edge.relationship.value
            relationship_types[rt] = relationship_types.get(rt, 0) + 1
        
        return {
            "total_nodes": len(self._nodes),
            "total_edges": len(self._edges),
            "node_types": node_types,
            "relationship_types": relationship_types,
            "has_cycles": len(self.detect_cycles()) > 0,
        }


# ============================================================================
# CLAIM LEDGER
# ============================================================================

@dataclass
class ClaimLedgerEntry:
    """Entry in the claim ledger."""
    claim: Claim
    evidence_ids: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    verification_history: list[dict[str, Any]] = field(default_factory=list)
    
    def add_verification_result(
        self,
        status: ClaimVerificationStatus,
        confidence: float,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        """Record a verification result."""
        self.verification_history.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "status": status.value,
            "confidence": confidence,
            "details": details or {},
        })
        self.updated_at = datetime.now(timezone.utc)


class ClaimLedger:
    """
    Ledger for tracking all claims and their verification status.
    
    Provides audit trail for claim verification and supports idempotency.
    """
    
    def __init__(self):
        self._entries: dict[str, ClaimLedgerEntry] = {}
        self._claim_hashes: dict[str, str] = {}  # hash -> claim_id for deduplication
    
    def _compute_claim_hash(self, claim_text: str) -> str:
        """Compute hash of claim text for deduplication."""
        import hashlib
        return hashlib.sha256(claim_text.encode("utf-8")).hexdigest()[:16]
    
    def add_claim(
        self,
        claim: Claim,
        evidence_ids: Optional[list[str]] = None,
    ) -> ClaimLedgerEntry:
        """Add a claim to the ledger."""
        # Check for duplicate
        claim_hash = self._compute_claim_hash(claim.text)
        
        if claim_hash in self._claim_hashes:
            existing_id = self._claim_hashes[claim_hash]
            if existing_id in self._entries:
                return self._entries[existing_id]
        
        entry = ClaimLedgerEntry(
            claim=claim,
            evidence_ids=evidence_ids or [],
        )
        
        self._entries[claim.claim_id] = entry
        self._claim_hashes[claim_hash] = claim.claim_id
        
        return entry
    
    def get_claim(self, claim_id: str) -> Optional[ClaimLedgerEntry]:
        """Get a claim entry by ID."""
        return self._entries.get(claim_id)
    
    def update_claim_status(
        self,
        claim_id: str,
        status: ClaimVerificationStatus,
        confidence: float,
        details: Optional[dict[str, Any]] = None,
    ) -> bool:
        """Update verification status for a claim."""
        entry = self._entries.get(claim_id)
        if not entry:
            return False
        
        entry.claim.verification_status = status
        entry.claim.confidence = confidence
        entry.add_verification_result(status, confidence, details)
        
        return True
    
    def add_evidence_to_claim(
        self,
        claim_id: str,
        evidence_id: str,
        is_supporting: bool = True,
    ) -> bool:
        """Add evidence to a claim."""
        entry = self._entries.get(claim_id)
        if not entry:
            return False
        
        if evidence_id not in entry.evidence_ids:
            entry.evidence_ids.append(evidence_id)
        
        if is_supporting:
            if evidence_id not in entry.claim.supporting_evidence_ids:
                entry.claim.supporting_evidence_ids.append(evidence_id)
        else:
            if evidence_id not in entry.claim.contradicting_evidence_ids:
                entry.claim.contradicting_evidence_ids.append(evidence_id)
        
        entry.updated_at = datetime.now(timezone.utc)
        return True
    
    def get_all_claims(
        self,
        status_filter: Optional[ClaimVerificationStatus] = None,
    ) -> list[ClaimLedgerEntry]:
        """Get all claims, optionally filtered by status."""
        if status_filter:
            return [
                entry for entry in self._entries.values()
                if entry.claim.verification_status == status_filter
            ]
        return list(self._entries.values())
    
    def get_unverified_claims(self) -> list[ClaimLedgerEntry]:
        """Get all claims that haven't been verified yet."""
        unverified_statuses = {
            ClaimVerificationStatus.PENDING,
        }
        return [
            entry for entry in self._entries.values()
            if entry.claim.verification_status in unverified_statuses
        ]
    
    def compute_ledger_statistics(self) -> dict[str, Any]:
        """Compute statistics about the claim ledger."""
        status_counts: dict[str, int] = {}
        
        for entry in self._entries.values():
            status = entry.claim.verification_status.value
            status_counts[status] = status_counts.get(status, 0) + 1
        
        avg_confidence = (
            sum(e.claim.confidence for e in self._entries.values()) /
            len(self._entries)
            if self._entries else 0.0
        )
        
        return {
            "total_claims": len(self._entries),
            "status_distribution": status_counts,
            "average_confidence": avg_confidence,
            "unverified_count": len(self.get_unverified_claims()),
        }


# ============================================================================
# PROVENANCE TRACKING
# ============================================================================

@dataclass
class ProvenanceRecord:
    """Record tracking the origin and transformation history of knowledge."""
    provenance_id: str
    source_id: str
    source_type: str  # document, database, api, user, etc.
    source_url: Optional[str]
    ingested_at: datetime
    transformations: list[dict[str, Any]] = field(default_factory=list)
    chain_of_custody: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def add_transformation(
        self,
        transformation_type: str,
        description: str,
        parameters: Optional[dict[str, Any]] = None,
    ) -> None:
        """Record a transformation applied to the knowledge."""
        self.transformations.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": transformation_type,
            "description": description,
            "parameters": parameters or {},
        })
    
    def add_custody_entry(
        self,
        actor: str,
        action: str,
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Record a custody transfer or access."""
        self.chain_of_custody.append({
            "timestamp": (timestamp or datetime.now(timezone.utc)).isoformat(),
            "actor": actor,
            "action": action,
        })
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "provenance_id": self.provenance_id,
            "source_id": self.source_id,
            "source_type": self.source_type,
            "source_url": self.source_url,
            "ingested_at": self.ingested_at.isoformat(),
            "transformations": self.transformations,
            "chain_of_custody": self.chain_of_custody,
            "metadata": self.metadata,
        }


class ProvenanceTracker:
    """
    Tracks provenance for all knowledge objects and evidence.
    
    Ensures full lineage tracking from source to final answer.
    """
    
    def __init__(self):
        self._records: dict[str, ProvenanceRecord] = {}
        self._knowledge_to_provenance: dict[str, str] = {}
    
    def create_record(
        self,
        source_id: str,
        source_type: str,
        source_url: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> ProvenanceRecord:
        """Create a new provenance record."""
        import uuid
        provenance_id = str(uuid.uuid4())
        
        record = ProvenanceRecord(
            provenance_id=provenance_id,
            source_id=source_id,
            source_type=source_type,
            source_url=source_url,
            ingested_at=datetime.now(timezone.utc),
            metadata=metadata or {},
        )
        
        self._records[provenance_id] = record
        return record
    
    def link_knowledge_object(
        self,
        knowledge_object_id: str,
        provenance_id: str,
    ) -> bool:
        """Link a knowledge object to its provenance record."""
        if provenance_id not in self._records:
            return False
        
        self._knowledge_to_provenance[knowledge_object_id] = provenance_id
        return True
    
    def get_provenance(self, knowledge_object_id: str) -> Optional[ProvenanceRecord]:
        """Get provenance record for a knowledge object."""
        provenance_id = self._knowledge_to_provenance.get(knowledge_object_id)
        if not provenance_id:
            return None
        return self._records.get(provenance_id)
    
    def record_transformation(
        self,
        knowledge_object_id: str,
        transformation_type: str,
        description: str,
        parameters: Optional[dict[str, Any]] = None,
    ) -> bool:
        """Record a transformation applied to a knowledge object."""
        provenance_id = self._knowledge_to_provenance.get(knowledge_object_id)
        if not provenance_id:
            return False
        
        record = self._records[provenance_id]
        record.add_transformation(transformation_type, description, parameters)
        return True
    
    def get_lineage(self, knowledge_object_id: str) -> list[dict[str, Any]]:
        """Get full lineage for a knowledge object."""
        provenance = self.get_provenance(knowledge_object_id)
        if not provenance:
            return []
        
        return provenance.to_dict()


# ============================================================================
# CONTRADICTION ENGINE
# ============================================================================

class ContradictionType(str, Enum):
    """Types of contradictions that can be detected."""
    SEMANTIC = "semantic"  # Direct semantic opposition
    TEMPORAL = "temporal"  # Conflicting time-based claims
    ENTITY_MISMATCH = "entity_mismatch"  # Conflicting entity attributes
    SCOPE_MISMATCH = "scope_mismatch"  # Different scopes/contexts
    SOURCE_DISAGREEMENT = "source_disagreement"  # Sources disagree


@dataclass
class ContradictionResult:
    """Result of contradiction analysis between two items."""
    item_a_id: str
    item_b_id: str
    has_contradiction: bool
    contradiction_type: Optional[ContradictionType]
    severity: float  # 0-1
    confidence: float  # 0-1
    explanation: str
    resolution_strategy: Optional[str] = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "item_a_id": self.item_a_id,
            "item_b_id": self.item_b_id,
            "has_contradiction": self.has_contradiction,
            "contradiction_type": self.contradiction_type.value if self.contradiction_type else None,
            "severity": self.severity,
            "confidence": self.confidence,
            "explanation": self.explanation,
            "resolution_strategy": self.resolution_strategy,
        }


class ContradictionEngine:
    """
    Detects and resolves contradictions between evidence and claims.
    
    Uses multiple strategies:
    - Semantic similarity analysis
    - Temporal validation
    - Entity comparison
    - Scope analysis
    """
    
    def __init__(self):
        self._detected_contradictions: list[ContradictionResult] = []
    
    def analyze_pair(
        self,
        item_a: Evidence | Claim,
        item_b: Evidence | Claim,
    ) -> ContradictionResult:
        """Analyze a pair of items for contradictions."""
        # Extract text content - Evidence uses text_span, Claim uses text
        text_a = getattr(item_a, 'text_span', None) or getattr(item_a, 'text', '')
        text_b = getattr(item_b, 'text_span', None) or getattr(item_b, 'text', '')
        
        # Check for semantic contradiction (simplified - would use NLI model in production)
        semantic_contradiction = self._check_semantic_contradiction(text_a, text_b)
        
        # Check for temporal contradiction
        temporal_contradiction = self._check_temporal_contradiction(item_a, item_b)
        
        # Determine primary contradiction type
        if temporal_contradiction:
            contradiction_type = ContradictionType.TEMPORAL
            severity = temporal_contradiction
        elif semantic_contradiction:
            contradiction_type = ContradictionType.SEMANTIC
            severity = semantic_contradiction
        else:
            contradiction_type = None
            severity = 0.0
        
        has_contradiction = severity > 0.5
        
        # Determine resolution strategy
        resolution_strategy = None
        if has_contradiction:
            resolution_strategy = self._suggest_resolution(
                contradiction_type,
                item_a,
                item_b,
            )
        
        result = ContradictionResult(
            item_a_id=item_a.evidence_id if hasattr(item_a, 'evidence_id') else getattr(item_a, 'claim_id', 'unknown_a'),
            item_b_id=item_b.evidence_id if hasattr(item_b, 'evidence_id') else getattr(item_b, 'claim_id', 'unknown_b'),
            has_contradiction=has_contradiction,
            contradiction_type=contradiction_type,
            severity=severity,
            confidence=0.8 if has_contradiction else 0.9,
            explanation=self._generate_explanation(contradiction_type, text_a, text_b),
            resolution_strategy=resolution_strategy,
        )
        
        if has_contradiction:
            self._detected_contradictions.append(result)
        
        return result
    
    def _check_semantic_contradiction(
        self,
        text_a: str,
        text_b: str,
    ) -> float:
        """
        Check for semantic contradiction between two texts.
        
        Returns contradiction severity (0-1).
        In production, this would use an NLI model.
        """
        # Simplified heuristic: look for negation patterns
        text_a_lower = text_a.lower()
        text_b_lower = text_b.lower()
        
        negation_patterns = [
            ("is not", "is"),
            ("are not", "are"),
            ("does not", "does"),
            ("never", "always"),
            ("impossible", "possible"),
            ("false", "true"),
        ]
        
        for neg, pos in negation_patterns:
            if neg in text_a_lower and pos in text_b_lower:
                # Check if they're talking about similar topics
                if self._texts_similar(text_a, text_b):
                    return 0.7
        
        return 0.0
    
    def _check_temporal_contradiction(
        self,
        item_a: Evidence | Claim,
        item_b: Evidence | Claim,
    ) -> Optional[float]:
        """Check for temporal contradictions."""
        # Get validity periods if available
        valid_from_a = getattr(item_a, 'valid_from', None)
        valid_until_a = getattr(item_a, 'valid_until', None)
        valid_from_b = getattr(item_b, 'valid_from', None)
        valid_until_b = getattr(item_b, 'valid_until', None)
        
        if not any([valid_from_a, valid_until_a, valid_from_b, valid_until_b]):
            return None
        
        # Check for non-overlapping validity periods with conflicting content
        if valid_until_a and valid_from_b and valid_until_a < valid_from_b:
            # Non-overlapping, might be updates rather than contradictions
            return None
        
        return None
    
    def _texts_similar(self, text_a: str, text_b: str) -> bool:
        """Check if two texts are discussing similar topics."""
        # Simple Jaccard similarity on words
        words_a = set(text_a.lower().split())
        words_b = set(text_b.lower().split())
        
        if not words_a or not words_b:
            return False
        
        intersection = len(words_a & words_b)
        union = len(words_a | words_b)
        
        return intersection / union > 0.3 if union > 0 else False
    
    def _suggest_resolution(
        self,
        contradiction_type: ContradictionType,
        item_a: Evidence | Claim,
        item_b: Evidence | Claim,
    ) -> str:
        """Suggest a resolution strategy for the contradiction."""
        if contradiction_type == ContradictionType.TEMPORAL:
            return "prefer_more_recent"
        elif contradiction_type == ContradictionType.SEMANTIC:
            return "prefer_higher_authority"
        elif contradiction_type == ContradictionType.ENTITY_MISMATCH:
            return "entity_resolution_required"
        elif contradiction_type == ContradictionType.SCOPE_MISMATCH:
            return "clarify_scope"
        else:
            return "manual_review"
    
    def _generate_explanation(
        self,
        contradiction_type: Optional[ContradictionType],
        text_a: str,
        text_b: str,
    ) -> str:
        """Generate human-readable explanation of the contradiction."""
        if not contradiction_type:
            return "No significant contradiction detected."
        
        explanations = {
            ContradictionType.SEMANTIC: (
                "The statements appear to express opposing views on the same topic."
            ),
            ContradictionType.TEMPORAL: (
                "The statements conflict due to different validity periods."
            ),
            ContradictionType.ENTITY_MISMATCH: (
                "The statements refer to the same entity but with conflicting attributes."
            ),
            ContradictionType.SCOPE_MISMATCH: (
                "The statements may both be true but apply to different contexts."
            ),
            ContradictionType.SOURCE_DISAGREEMENT: (
                "Different sources provide conflicting information."
            ),
        }
        
        return explanations.get(contradiction_type, "Contradiction detected.")
    
    def analyze_evidence_set(
        self,
        evidence_list: list[Evidence],
    ) -> list[ContradictionResult]:
        """Analyze a set of evidence for pairwise contradictions."""
        results = []
        
        for i, item_a in enumerate(evidence_list):
            for j, item_b in enumerate(evidence_list):
                if i >= j:
                    continue
                
                result = self.analyze_pair(item_a, item_b)
                results.append(result)
        
        return results
    
    def get_detected_contradictions(self) -> list[ContradictionResult]:
        """Get all detected contradictions."""
        return self._detected_contradictions.copy()
    
    def clear_history(self) -> None:
        """Clear contradiction detection history."""
        self._detected_contradictions.clear()


# ============================================================================
# TEMPORAL RESOLUTION
# ============================================================================

@dataclass
class TemporalContext:
    """Temporal context for knowledge validation."""
    reference_time: datetime
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    
    def is_valid(self) -> bool:
        """Check if the temporal context is currently valid."""
        now = datetime.now(timezone.utc)
        
        if self.valid_from and now < self.valid_from:
            return False
        if self.valid_until and now > self.valid_until:
            return False
        
        return True
    
    def overlaps_with(self, other: "TemporalContext") -> bool:
        """Check if this context overlaps with another."""
        if self.valid_from and other.valid_until:
            if self.valid_from > other.valid_until:
                return False
        if self.valid_until and other.valid_from:
            if self.valid_until < other.valid_from:
                return False
        
        return True


class TemporalResolver:
    """
    Resolves temporal conflicts and validates knowledge currency.
    
    Handles:
    - Time-sensitive queries
    - Historical vs current knowledge
    - Superseded information
    - Validity period conflicts
    """
    
    def __init__(self):
        self._knowledge_timestamps: dict[str, TemporalContext] = {}
    
    def register_knowledge(
        self,
        knowledge_id: str,
        valid_from: Optional[datetime] = None,
        valid_until: Optional[datetime] = None,
    ) -> TemporalContext:
        """Register temporal context for a knowledge object."""
        context = TemporalContext(
            reference_time=datetime.now(timezone.utc),
            valid_from=valid_from,
            valid_until=valid_until,
        )
        
        self._knowledge_timestamps[knowledge_id] = context
        return context
    
    def is_current(self, knowledge_id: str) -> bool:
        """Check if knowledge is currently valid."""
        context = self._knowledge_timestamps.get(knowledge_id)
        if not context:
            return True  # Assume current if no temporal info
        
        return context.is_valid()
    
    def filter_current(
        self,
        knowledge_ids: list[str],
    ) -> list[str]:
        """Filter to only currently valid knowledge IDs."""
        return [
            kid for kid in knowledge_ids
            if self.is_current(kid)
        ]
    
    def resolve_conflict(
        self,
        knowledge_a_id: str,
        knowledge_b_id: str,
    ) -> str:
        """
        Resolve conflict between two knowledge objects based on temporality.
        
        Returns the ID of the preferred knowledge object.
        """
        context_a = self._knowledge_timestamps.get(knowledge_a_id)
        context_b = self._knowledge_timestamps.get(knowledge_b_id)
        
        if not context_a and not context_b:
            return knowledge_a_id  # No preference
        
        if not context_a:
            return knowledge_b_id
        if not context_b:
            return knowledge_a_id
        
        # Prefer more recent valid_until (more current information)
        if context_a.valid_until and context_b.valid_until:
            if context_a.valid_until > context_b.valid_until:
                return knowledge_a_id
            return knowledge_b_id
        
        # Prefer later valid_from (more recent knowledge)
        if context_a.valid_from and context_b.valid_from:
            if context_a.valid_from > context_b.valid_from:
                return knowledge_a_id
            return knowledge_b_id
        
        return knowledge_a_id
    
    def get_valid_at(
        self,
        knowledge_id: str,
        timestamp: datetime,
    ) -> bool:
        """Check if knowledge was valid at a specific timestamp."""
        context = self._knowledge_timestamps.get(knowledge_id)
        if not context:
            return True
        
        if context.valid_from and timestamp < context.valid_from:
            return False
        if context.valid_until and timestamp > context.valid_until:
            return False
        
        return True
    
    def find_superseding(
        self,
        knowledge_id: str,
        all_knowledge: list[CanonicalKnowledgeObject],
    ) -> Optional[str]:
        """Find knowledge that supersedes the given knowledge."""
        context = self._knowledge_timestamps.get(knowledge_id)
        if not context:
            return None
        
        for ko in all_knowledge:
            if ko.id == knowledge_id:
                continue
            
            # Check if this knowledge supersedes
            if hasattr(ko, 'superseded_by') and ko.superseded_by:
                continue
            
            ko_context = self._knowledge_timestamps.get(ko.id)
            if not ko_context:
                continue
            
            # Check if ko is more recent and covers same period
            if (
                ko_context.valid_from and
                context.valid_from and
                ko_context.valid_from > context.valid_from
            ):
                return ko.id
        
        return None


# ============================================================================
# MAIN EVIDENCE SERVICE
# ============================================================================

class EvidenceService:
    """
    Main service coordinating evidence management.
    
    Integrates:
    - Evidence graph
    - Claim ledger
    - Provenance tracking
    - Contradiction detection
    - Temporal resolution
    """
    
    def __init__(self):
        self.graph = EvidenceGraph()
        self.ledger = ClaimLedger()
        self.provenance = ProvenanceTracker()
        self.contradiction_engine = ContradictionEngine()
        self.temporal_resolver = TemporalResolver()
    
    async def initialize(self) -> None:
        """Initialize the evidence service."""
        pass  # Async initialization if needed
    
    def process_evidence(
        self,
        evidence: Evidence,
        knowledge_object: Optional[CanonicalKnowledgeObject] = None,
    ) -> str:
        """Process and store evidence."""
        # Create provenance if knowledge object provided
        if knowledge_object:
            prov_record = self.provenance.create_record(
                source_id=knowledge_object.source_id,
                source_type="document",
            )
            self.provenance.link_knowledge_object(
                knowledge_object.id,
                prov_record.provenance_id,
            )
        
        # Register temporal context
        if knowledge_object:
            self.temporal_resolver.register_knowledge(
                knowledge_object.id,
                valid_from=knowledge_object.valid_from,
                valid_until=knowledge_object.valid_until,
            )
        
        # Add to graph
        self.graph.add_node(
            node_id=evidence.id,
            node_type=GraphNodeType.CHUNK,
            content=evidence.content,
            metadata={
                "source_id": evidence.source_id,
                "relevance_score": evidence.relevance_score,
                "authority_score": evidence.authority_score,
            },
        )
        
        return evidence.id
    
    def process_claim(
        self,
        claim: Claim,
        evidence_ids: Optional[list[str]] = None,
    ) -> str:
        """Process and verify a claim."""
        # Add to ledger
        entry = self.ledger.add_claim(claim, evidence_ids)
        
        # Add to graph
        self.graph.add_node(
            node_id=claim.claim_id,
            node_type=GraphNodeType.CLAIM,
            content=claim.text,
            metadata={
                "claim_type": claim.claim_type,
                "verification_status": claim.verification_status.value,
            },
        )
        
        # Link to evidence in graph
        for evidence_id in (evidence_ids or []):
            if evidence_id in self.graph._nodes:
                relationship = (
                    GraphRelationship.SUPPORTS
                    if evidence_id in claim.supporting_evidence_ids
                    else GraphRelationship.CONTRADICTS
                    if evidence_id in claim.contradicting_evidence_ids
                    else GraphRelationship.RELATED_TO
                )
                
                import uuid
                self.graph.add_edge(
                    edge_id=str(uuid.uuid4()),
                    source_node_id=claim.claim_id,
                    target_node_id=evidence_id,
                    relationship=relationship,
                )
        
        return claim.claim_id
    
    def verify_claim(
        self,
        claim_id: str,
        evidence_list: list[Evidence],
    ) -> ClaimVerificationStatus:
        """Verify a claim against evidence."""
        entry = self.ledger.get_claim(claim_id)
        if not entry:
            return ClaimVerificationStatus.PENDING
        
        # Analyze contradictions
        claim_node = self.graph.get_node(claim_id)
        if not claim_node:
            return ClaimVerificationStatus.PENDING
        
        contradictions = self.contradiction_engine.analyze_evidence_set(evidence_list)
        
        # Update claim based on evidence
        supporting_count = 0
        contradicting_count = 0
        
        for evidence in evidence_list:
            # Add evidence to graph if not present
            if evidence.id not in self.graph._nodes:
                self.process_evidence(evidence)
            
            # Check relationship
            contradiction_results = [
                c for c in contradictions
                if c.item_a_id == evidence.id or c.item_b_id == evidence.id
            ]
            
            has_strong_contradiction = any(
                c.has_contradiction and c.severity > 0.7
                for c in contradiction_results
            )
            
            if has_strong_contradiction:
                contradicting_count += 1
                self.ledger.add_evidence_to_claim(claim_id, evidence.id, is_supporting=False)
            else:
                supporting_count += 1
                self.ledger.add_evidence_to_claim(claim_id, evidence.id, is_supporting=True)
        
        # Update claim scores
        total = supporting_count + contradicting_count
        if total > 0:
            entry.claim.support_score = supporting_count / total
            entry.claim.contradiction_score = contradicting_count / total
        
        # Determine status
        entry.claim.update_verification_status()
        
        # Record verification
        self.ledger.update_claim_status(
            claim_id,
            entry.claim.verification_status,
            entry.claim.confidence,
        )
        
        return entry.claim.verification_status
    
    def get_claim_subgraph(self, claim_id: str) -> dict[str, Any]:
        """Get the evidence subgraph for a claim."""
        return self.graph.get_subgraph_for_claim(claim_id, depth=2)
    
    def get_contradictions(self) -> list[dict[str, Any]]:
        """Get all detected contradictions."""
        return [c.to_dict() for c in self.contradiction_engine.get_detected_contradictions()]
    
    def get_statistics(self) -> dict[str, Any]:
        """Get comprehensive statistics."""
        return {
            "graph": self.graph.statistics(),
            "ledger": self.ledger.compute_ledger_statistics(),
            "contradictions": len(self.get_contradictions()),
        }


__all__ = [
    # Graph
    "EvidenceGraph",
    "GraphNode",
    "GraphEdge",
    "GraphNodeType",
    "GraphRelationship",
    # Claim Ledger
    "ClaimLedger",
    "ClaimLedgerEntry",
    # Provenance
    "ProvenanceTracker",
    "ProvenanceRecord",
    # Contradiction
    "ContradictionEngine",
    "ContradictionResult",
    "ContradictionType",
    # Temporal
    "TemporalResolver",
    "TemporalContext",
    # Service
    "EvidenceService",
]
