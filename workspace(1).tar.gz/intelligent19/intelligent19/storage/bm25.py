"""
BM25 lexical search implementation.

Provides keyword-based search using the BM25 algorithm.
Used as part of hybrid retrieval alongside dense vectors.
"""

from __future__ import annotations

import hashlib
from datetime import datetime
from typing import Any

from rank_bm25 import BM25Okapi

from .base import BaseStorage, HealthStatus, LexicalStoreProtocol, StorageStats


class BM25LexicalStore(BaseStorage):
    """
    In-memory BM25 lexical search store.
    
    Implements LexicalStoreProtocol for type-safe access.
    Note: For production use with large document sets, consider
    using Elasticsearch or Meilisearch instead.
    """
    
    def __init__(self, tenant_id: str | None = None):
        super().__init__(tenant_id)
        
        # Documents indexed by tenant
        self._documents: dict[str, dict[str, str]] = {}  # tenant_id -> {doc_id -> text}
        self._tokenized_docs: dict[str, list[list[str]]] = {}  # tenant_id -> tokenized docs
        
        # BM25 index per tenant
        self._bm25_indices: dict[str, BM25Okapi | None] = {}
        
        # Document IDs for lookup
        self._doc_ids: dict[str, list[str]] = {}  # tenant_id -> [doc_ids]
    
    def _tokenize(self, text: str) -> list[str]:
        """Simple tokenization: lowercase and split on non-alphanumeric."""
        import re
        return re.findall(r'\w+', text.lower())
    
    def _compute_hash(self, content: str) -> str:
        """Compute SHA-256 hash of content."""
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    async def initialize(self) -> None:
        """Initialize storage (no-op for in-memory)."""
        self._initialized = True
    
    async def close(self) -> None:
        """Close storage (clear memory)."""
        self._documents.clear()
        self._tokenized_docs.clear()
        self._bm25_indices.clear()
        self._doc_ids.clear()
        self._initialized = False
    
    async def health_check(self) -> HealthStatus:
        """Check storage health."""
        return HealthStatus.HEALTHY if self._initialized else HealthStatus.UNHEALTHY
    
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        total_docs = sum(len(docs) for docs in self._documents.values())
        total_bytes = sum(
            len(text) for tenant_docs in self._documents.values() for text in tenant_docs.values()
        )
        
        return StorageStats(
            item_count=total_docs,
            size_bytes=total_bytes,
            last_updated=datetime.utcnow(),
        )
    
    async def index_documents(
        self,
        documents: dict[str, str],
        tenant_id: str,
    ) -> int:
        """Index documents for lexical search."""
        self._validate_tenant_id(tenant_id)
        
        # Initialize tenant storage if needed
        if tenant_id not in self._documents:
            self._documents[tenant_id] = {}
            self._tokenized_docs[tenant_id] = []
            self._doc_ids[tenant_id] = []
            self._bm25_indices[tenant_id] = None
        
        # Add new documents
        for doc_id, text in documents.items():
            if doc_id not in self._documents[tenant_id]:
                self._documents[tenant_id][doc_id] = text
                self._tokenized_docs[tenant_id].append(self._tokenize(text))
                self._doc_ids[tenant_id].append(doc_id)
        
        # Rebuild BM25 index
        if self._tokenized_docs[tenant_id]:
            self._bm25_indices[tenant_id] = BM25Okapi(self._tokenized_docs[tenant_id])
        
        return len(documents)
    
    async def search(
        self,
        query: str,
        limit: int,
        tenant_id: str,
    ) -> list[tuple[str, float, str]]:
        """Search documents lexically with tenant isolation."""
        self._validate_tenant_id(tenant_id)
        
        if tenant_id not in self._bm25_indices or self._bm25_indices[tenant_id] is None:
            return []
        
        bm25 = self._bm25_indices[tenant_id]
        tokenized_query = self._tokenize(query)
        
        # Get BM25 scores
        scores = bm25.get_scores(tokenized_query)
        
        # Get top results
        results = []
        doc_ids = self._doc_ids.get(tenant_id, [])
        
        for idx, score in enumerate(scores):
            if idx < len(doc_ids) and score > 0:
                doc_id = doc_ids[idx]
                text = self._documents[tenant_id].get(doc_id, "")
                results.append((doc_id, float(score), text))
        
        # Sort by score descending
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:limit]
    
    async def delete(self, ids: list[str], tenant_id: str) -> bool:
        """Delete documents by ID."""
        self._validate_tenant_id(tenant_id)
        
        if tenant_id not in self._documents:
            return False
        
        deleted = 0
        for doc_id in ids:
            if doc_id in self._documents[tenant_id]:
                # Find index
                try:
                    idx = self._doc_ids[tenant_id].index(doc_id)
                    
                    # Remove from all structures
                    del self._documents[tenant_id][doc_id]
                    del self._tokenized_docs[tenant_id][idx]
                    del self._doc_ids[tenant_id][idx]
                    
                    deleted += 1
                except ValueError:
                    pass
        
        # Rebuild index if documents were deleted
        if deleted > 0 and self._tokenized_docs[tenant_id]:
            self._bm25_indices[tenant_id] = BM25Okapi(self._tokenized_docs[tenant_id])
        elif deleted > 0:
            self._bm25_indices[tenant_id] = None
        
        return deleted > 0
    
    async def get_document(
        self,
        doc_id: str,
        tenant_id: str,
    ) -> str | None:
        """Get document by ID."""
        self._validate_tenant_id(tenant_id)
        
        if tenant_id not in self._documents:
            return None
        
        return self._documents[tenant_id].get(doc_id)
    
    async def list_documents(
        self,
        tenant_id: str,
        limit: int = 100,
    ) -> list[str]:
        """List document IDs for tenant."""
        self._validate_tenant_id(tenant_id)
        
        if tenant_id not in self._doc_ids:
            return []
        
        return self._doc_ids[tenant_id][:limit]


__all__ = ["BM25LexicalStore"]
