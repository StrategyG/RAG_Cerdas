"""
Redis cache implementation.

Provides fast caching for query results, embeddings, and intermediate data.
Implements graceful degradation when Redis is unavailable.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from .base import BaseStorage, HealthStatus, CacheProtocol, StorageStats


class RedisCache(BaseStorage):
    """
    Redis cache for fast lookups.
    
    Implements CacheProtocol for type-safe access.
    Provides graceful degradation when Redis is unavailable.
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        tenant_id: str | None = None,
        default_ttl_seconds: int = 3600,
        timeout_seconds: float = 2.0,
    ):
        super().__init__(tenant_id)
        
        self.host = host
        self.port = port
        self.db = db
        self.default_ttl = default_ttl_seconds
        self.timeout_seconds = timeout_seconds
        
        self._client = None
        self._available = False
    
    @property
    def connection_url(self) -> str:
        """Build Redis connection URL."""
        return f"redis://{self.host}:{self.port}/{self.db}"
    
    async def initialize(self) -> None:
        """Initialize Redis client."""
        try:
            # Lazy import to avoid dependency errors in tests
            import redis.asyncio as redis
            
            self._client = redis.Redis(
                host=self.host,
                port=self.port,
                db=self.db,
                socket_timeout=self.timeout_seconds,
                socket_connect_timeout=self.timeout_seconds,
                decode_responses=True,
            )
            
            # Test connection
            await self._client.ping()
            self._available = True
            self._initialized = True
            
        except Exception as e:
            # Graceful degradation: mark as unavailable but don't crash
            self._available = False
            self._initialized = False
    
    async def close(self) -> None:
        """Close Redis client."""
        if self._client:
            await self._client.close()
            self._initialized = False
            self._available = False
    
    async def health_check(self) -> HealthStatus:
        """Check Redis health."""
        if not self._initialized:
            return HealthStatus.UNHEALTHY
        
        try:
            import asyncio
            
            await asyncio.wait_for(
                self._client.ping(),
                timeout=self.timeout_seconds,
            )
            return HealthStatus.HEALTHY if self._available else HealthStatus.DEGRADED
        except Exception:
            return HealthStatus.UNHEALTHY
    
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        if not self._initialized or not self._available:
            return StorageStats()
        
        try:
            info = await self._client.info("memory")
            used_memory = info.get("used_memory", 0)
            
            return StorageStats(
                size_bytes=int(used_memory),
                last_updated=datetime.utcnow(),
            )
        except Exception:
            return StorageStats()
    
    def _make_key(self, key: str) -> str:
        """Create namespaced key with tenant isolation."""
        if self.tenant_id:
            return f"tenant:{self.tenant_id}:{key}"
        return key
    
    async def get(self, key: str) -> Any | None:
        """Get value from cache."""
        if not self._available:
            return None
        
        try:
            value = await self._client.get(self._make_key(key))
            if value is None:
                return None
            
            # Try to parse as JSON
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        except Exception:
            return None
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> bool:
        """Set value in cache."""
        if not self._available:
            return False
        
        try:
            # Serialize value
            if isinstance(value, (dict, list)):
                serialized = json.dumps(value)
            else:
                serialized = str(value)
            
            ttl = ttl_seconds or self.default_ttl
            
            await self._client.setex(
                self._make_key(key),
                ttl,
                serialized,
            )
            return True
        except Exception:
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        if not self._available:
            return False
        
        try:
            result = await self._client.delete(self._make_key(key))
            return result > 0
        except Exception:
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        if not self._available:
            return False
        
        try:
            result = await self._client.exists(self._make_key(key))
            return result > 0
        except Exception:
            return False
    
    async def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Get multiple values from cache."""
        if not self._available:
            return {}
        
        try:
            prefixed_keys = [self._make_key(k) for k in keys]
            values = await self._client.mget(prefixed_keys)
            
            result = {}
            for key, value in zip(keys, values):
                if value is not None:
                    try:
                        result[key] = json.loads(value)
                    except (json.JSONDecodeError, TypeError):
                        result[key] = value
            
            return result
        except Exception:
            return {}
    
    async def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern."""
        if not self._available:
            return 0
        
        try:
            prefixed_pattern = self._make_key(pattern)
            keys = []
            
            async for key in self._client.scan_iter(match=prefixed_pattern):
                keys.append(key)
            
            if keys:
                return await self._client.delete(*keys)
            return 0
        except Exception:
            return 0
    
    def is_available(self) -> bool:
        """Check if Redis is available."""
        return self._available and self._initialized


__all__ = ["RedisCache"]
