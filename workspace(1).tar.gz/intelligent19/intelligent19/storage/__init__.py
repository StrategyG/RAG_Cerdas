"""
Storage abstraction layer.

Provides protocol-based interfaces for all storage backends.
Concrete implementations are in separate modules.
"""

from .base import StorageProtocol, HealthStatus
from .postgres import PostgreSQLStorage
from .qdrant import QdrantVectorStore
from .bm25 import BM25LexicalStore
from .redis import RedisCache

__all__ = [
    "StorageProtocol",
    "HealthStatus",
    "PostgreSQLStorage",
    "QdrantVectorStore",
    "BM25LexicalStore",
    "RedisCache",
]
