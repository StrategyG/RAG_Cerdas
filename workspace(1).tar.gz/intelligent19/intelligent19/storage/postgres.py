"""
PostgreSQL metadata storage implementation.

Provides relational storage for canonical knowledge objects,
provenance records, and system metadata.
"""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from sqlalchemy import Column, DateTime, Index, String, Text, Float, Integer, JSON
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from .base import BaseStorage, HealthStatus, MetadataStoreProtocol, StorageStats


class Base(DeclarativeBase):
    """SQLAlchemy declarative base."""
    pass


class KnowledgeObjectORM(Base):
    """ORM model for canonical knowledge objects."""
    
    __tablename__ = "knowledge_objects"
    
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    source_id: Mapped[str] = mapped_column(String(256), nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    
    content: Mapped[str] = mapped_column(Text, nullable=False)
    knowledge_type: Mapped[str] = mapped_column(String(64), nullable=False)
    
    entity_ids: Mapped[list[str]] = mapped_column(JSON, default=list)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    valid_from: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    superseded_by: Mapped[str | None] = mapped_column(String(64), nullable=True)
    
    authority_score: Mapped[float] = mapped_column(Float, default=0.5)
    trust_level: Mapped[str] = mapped_column(String(64), default="unverified")
    
    version: Mapped[int] = mapped_column(Integer, default=1)
    embedding_version: Mapped[str | None] = mapped_column(String(128), nullable=True)
    
    provenance_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    metadata: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # Composite index for tenant isolation + common queries
    __table_args__ = (
        Index("idx_tenant_type", "tenant_id", "knowledge_type"),
        Index("idx_tenant_valid", "tenant_id", "valid_from", "valid_until"),
    )


class PostgreSQLStorage(BaseStorage):
    """
    PostgreSQL storage for metadata and canonical knowledge objects.
    
    Implements MetadataStoreProtocol for type-safe access.
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "intelligent19",
        user: str = "intelligent19",
        password: str = "changeme",
        tenant_id: str | None = None,
        pool_size: int = 10,
        max_overflow: int = 20,
    ):
        super().__init__(tenant_id)
        
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        
        self._engine = None
        self._session_factory = None
    
    @property
    def connection_url(self) -> str:
        """Build PostgreSQL connection URL."""
        return (
            f"postgresql+asyncpg://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.database}"
        )
    
    async def initialize(self) -> None:
        """Initialize database connection and create tables."""
        try:
            self._engine = create_async_engine(
                self.connection_url,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                echo=False,
            )
            
            self._session_factory = async_sessionmaker(
                self._engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )
            
            # Create tables
            async with self._engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            
            self._initialized = True
        except Exception as e:
            raise ConnectionError(f"Failed to initialize PostgreSQL: {e}")
    
    async def close(self) -> None:
        """Close database connections."""
        if self._engine:
            await self._engine.dispose()
            self._initialized = False
    
    async def health_check(self) -> HealthStatus:
        """Check database health."""
        if not self._initialized:
            return HealthStatus.UNHEALTHY
        
        try:
            async with self._session_factory() as session:
                from sqlalchemy import text
                await session.execute(text("SELECT 1"))
            return HealthStatus.HEALTHY
        except Exception:
            return HealthStatus.UNHEALTHY
    
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        if not self._initialized:
            return StorageStats()
        
        try:
            async with self._session_factory() as session:
                from sqlalchemy import func, select
                
                result = await session.execute(
                    select(func.count(KnowledgeObjectORM.id))
                )
                count = result.scalar() or 0
            
            return StorageStats(
                item_count=count,
                last_updated=datetime.utcnow(),
            )
        except Exception:
            return StorageStats()
    
    @asynccontextmanager
    async def _get_session(self):
        """Get database session context manager."""
        if not self._initialized:
            raise RuntimeError("Storage not initialized")
        
        async with self._session_factory() as session:
            yield session
    
    async def insert(
        self,
        table: str,
        data: dict[str, Any],
        tenant_id: str,
    ) -> str:
        """Insert record into specified table."""
        self._validate_tenant_id(tenant_id)
        
        if table != "knowledge_objects":
            raise ValueError(f"Unsupported table: {table}")
        
        async with self._get_session() as session:
            obj = KnowledgeObjectORM(
                **data,
                tenant_id=tenant_id,
            )
            session.add(obj)
            await session.commit()
            await session.refresh(obj)
            return obj.id
    
    async def query(
        self,
        table: str,
        filters: dict[str, Any],
        tenant_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query records with filters."""
        self._validate_tenant_id(tenant_id)
        
        if table != "knowledge_objects":
            raise ValueError(f"Unsupported table: {table}")
        
        async with self._get_session() as session:
            from sqlalchemy import select
            
            stmt = select(KnowledgeObjectORM).where(
                KnowledgeObjectORM.tenant_id == tenant_id
            )
            
            # Apply filters
            for key, value in filters.items():
                if hasattr(KnowledgeObjectORM, key):
                    column = getattr(KnowledgeObjectORM, key)
                    stmt = stmt.where(column == value)
            
            stmt = stmt.limit(limit)
            result = await session.execute(stmt)
            
            return [
                {
                    "id": row.id,
                    "tenant_id": row.tenant_id,
                    "source_id": row.source_id,
                    "content_hash": row.content_hash,
                    "content": row.content,
                    "knowledge_type": row.knowledge_type,
                    "entity_ids": row.entity_ids,
                    "created_at": row.created_at.isoformat() if row.created_at else None,
                    "valid_from": row.valid_from.isoformat() if row.valid_from else None,
                    "valid_until": row.valid_until.isoformat() if row.valid_until else None,
                    "superseded_by": row.superseded_by,
                    "authority_score": row.authority_score,
                    "trust_level": row.trust_level,
                    "version": row.version,
                    "embedding_version": row.embedding_version,
                    "provenance_id": row.provenance_id,
                    "metadata": row.metadata,
                }
                for row in result.scalars()
            ]
    
    async def update(
        self,
        table: str,
        id: str,
        data: dict[str, Any],
        tenant_id: str,
    ) -> bool:
        """Update record by ID."""
        self._validate_tenant_id(tenant_id)
        
        if table != "knowledge_objects":
            raise ValueError(f"Unsupported table: {table}")
        
        async with self._get_session() as session:
            from sqlalchemy import select, update
            
            stmt = select(KnowledgeObjectORM).where(
                KnowledgeObjectORM.id == id,
                KnowledgeObjectORM.tenant_id == tenant_id,
            )
            result = await session.execute(stmt)
            obj = result.scalar_one_or_none()
            
            if not obj:
                return False
            
            for key, value in data.items():
                if hasattr(obj, key):
                    setattr(obj, key, value)
            
            await session.commit()
            return True
    
    async def delete(
        self,
        table: str,
        id: str,
        tenant_id: str,
    ) -> bool:
        """Delete record by ID."""
        self._validate_tenant_id(tenant_id)
        
        if table != "knowledge_objects":
            raise ValueError(f"Unsupported table: {table}")
        
        async with self._get_session() as session:
            from sqlalchemy import delete
            
            stmt = delete(KnowledgeObjectORM).where(
                KnowledgeObjectORM.id == id,
                KnowledgeObjectORM.tenant_id == tenant_id,
            )
            result = await session.execute(stmt)
            await session.commit()
            
            return result.rowcount > 0


__all__ = ["PostgreSQLStorage", "KnowledgeObjectORM"]
