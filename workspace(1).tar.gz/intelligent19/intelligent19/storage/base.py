"""
Base storage protocol and types.

Defines the abstract interfaces that all storage implementations must follow.
Uses Python Protocol for structural subtyping.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Generic, Protocol, TypeVar

T = TypeVar("T")


class HealthStatus(str, Enum):
    """Health status of a storage backend."""
    
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class StorageStats:
    """Statistics for storage backend."""
    
    item_count: int = 0
    size_bytes: int = 0
    last_updated: datetime | None = None
    read_latency_ms: float | None = None
    write_latency_ms: float | None = None


class StorageProtocol(Protocol):
    """Protocol for storage backends."""
    
    async def health_check(self) -> HealthStatus:
        """Check health of storage backend."""
        ...
    
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        ...


class BaseStorage(ABC):
    """Abstract base class for storage implementations."""
    
    def __init__(self, tenant_id: str | None = None):
        self.tenant_id = tenant_id
        self._initialized = False
    
    @abstractmethod
    async def initialize(self) -> None:
        """Initialize storage connection."""
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """Close storage connection."""
        pass
    
    @abstractmethod
    async def health_check(self) -> HealthStatus:
        """Check health of storage backend."""
        pass
    
    @abstractmethod
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        pass
    
    def _validate_tenant_id(self, tenant_id: str) -> None:
        """Validate tenant ID for isolation."""
        if self.tenant_id and tenant_id != self.tenant_id:
            raise ValueError(
                f"Tenant ID mismatch: expected {self.tenant_id}, got {tenant_id}. "
                "This may indicate a tenant isolation violation."
            )


class VectorStoreProtocol(Protocol):
    """Protocol for vector storage backends."""
    
    async def upsert(
        self,
        ids: list[str],
        vectors: list[list[float]],
        payloads: list[dict[str, Any]],
        tenant_id: str,
    ) -> bool:
        """Upsert vectors with payloads."""
        ...
    
    async def search(
        self,
        vector: list[float],
        limit: int,
        tenant_id: str,
        filter_dict: dict[str, Any] | None = None,
    ) -> list[tuple[str, float, dict[str, Any]]]:
        """Search for similar vectors."""
        ...
    
    async def delete(self, ids: list[str], tenant_id: str) -> bool:
        """Delete vectors by ID."""
        ...


class LexicalStoreProtocol(Protocol):
    """Protocol for lexical/BM25 storage backends."""
    
    async def index_documents(
        self,
        documents: dict[str, str],
        tenant_id: str,
    ) -> int:
        """Index documents for lexical search."""
        ...
    
    async def search(
        self,
        query: str,
        limit: int,
        tenant_id: str,
    ) -> list[tuple[str, float, str]]:
        """Search documents lexically."""
        ...
    
    async def delete(self, ids: list[str], tenant_id: str) -> bool:
        """Delete documents by ID."""
        ...


class MetadataStoreProtocol(Protocol):
    """Protocol for metadata/relational storage backends."""
    
    async def insert(
        self,
        table: str,
        data: dict[str, Any],
        tenant_id: str,
    ) -> str:
        """Insert record and return ID."""
        ...
    
    async def query(
        self,
        table: str,
        filters: dict[str, Any],
        tenant_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query records with filters."""
        ...
    
    async def update(
        self,
        table: str,
        id: str,
        data: dict[str, Any],
        tenant_id: str,
    ) -> bool:
        """Update record by ID."""
        ...
    
    async def delete(
        self,
        table: str,
        id: str,
        tenant_id: str,
    ) -> bool:
        """Delete record by ID."""
        ...


class CacheProtocol(Protocol):
    """Protocol for cache backends."""
    
    async def get(self, key: str) -> Any | None:
        """Get value from cache."""
        ...
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> bool:
        """Set value in cache."""
        ...
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        ...
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        ...


__all__ = [
    "HealthStatus",
    "StorageStats",
    "StorageProtocol",
    "BaseStorage",
    "VectorStoreProtocol",
    "LexicalStoreProtocol",
    "MetadataStoreProtocol",
    "CacheProtocol",
]
