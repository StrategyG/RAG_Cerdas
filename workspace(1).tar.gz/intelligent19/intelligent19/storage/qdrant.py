"""
Qdrant vector storage implementation.

Provides vector similarity search for dense embeddings.
Implements graceful degradation when Qdrant is unavailable.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

from .base import BaseStorage, HealthStatus, StorageStats, VectorStoreProtocol


class QdrantVectorStore(BaseStorage):
    """
    Qdrant vector storage for dense retrieval.
    
    Implements VectorStoreProtocol for type-safe access.
    Provides graceful degradation when Qdrant is unavailable.
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6333,
        collection_name: str = "knowledge",
        tenant_id: str | None = None,
        embedding_dim: int = 1024,
        distance: str = "cosine",
        timeout_seconds: float = 5.0,
    ):
        super().__init__(tenant_id)
        
        self.host = host
        self.port = port
        self.collection_name = collection_name
        self.embedding_dim = embedding_dim
        self.distance = distance
        self.timeout_seconds = timeout_seconds
        
        self._client = None
        self._available = False
    
    @property
    def connection_url(self) -> str:
        """Build Qdrant connection URL."""
        return f"http://{self.host}:{self.port}"
    
    async def initialize(self) -> None:
        """Initialize Qdrant client and collection."""
        try:
            # Lazy import to avoid dependency errors in tests
            from qdrant_client import AsyncQdrantClient
            from qdrant_client.models import (
                Distance,
                VectorParams,
                PointStruct,
            )
            
            self._client = AsyncQdrantClient(
                host=self.host,
                port=self.port,
                timeout=int(self.timeout_seconds),
            )
            
            # Check if collection exists
            collections = await self._client.get_collections()
            collection_names = [c.name for c in collections.collections]
            
            if self.collection_name not in collection_names:
                # Create collection
                distance_type = Distance.COSINE if self.distance == "cosine" else Distance.EUCLID
                
                await self._client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(
                        size=self.embedding_dim,
                        distance=distance_type,
                    ),
                )
            
            self._available = True
            self._initialized = True
            
        except Exception as e:
            # Graceful degradation: mark as unavailable but don't crash
            self._available = False
            self._initialized = False
    
    async def close(self) -> None:
        """Close Qdrant client."""
        if self._client:
            await self._client.close()
            self._initialized = False
            self._available = False
    
    async def health_check(self) -> HealthStatus:
        """Check Qdrant health."""
        if not self._initialized:
            return HealthStatus.UNHEALTHY
        
        try:
            # Quick health check with timeout
            await asyncio.wait_for(
                self._client.get_collections(),
                timeout=self.timeout_seconds,
            )
            return HealthStatus.HEALTHY if self._available else HealthStatus.DEGRADED
        except asyncio.TimeoutError:
            return HealthStatus.DEGRADED
        except Exception:
            return HealthStatus.UNHEALTHY
    
    async def get_stats(self) -> StorageStats:
        """Get storage statistics."""
        if not self._initialized or not self._available:
            return StorageStats()
        
        try:
            info = await self._client.get_collection(self.collection_name)
            return StorageStats(
                item_count=info.points_count,
                last_updated=datetime.utcnow(),
            )
        except Exception:
            return StorageStats()
    
    async def upsert(
        self,
        ids: list[str],
        vectors: list[list[float]],
        payloads: list[dict[str, Any]],
        tenant_id: str,
    ) -> bool:
        """Upsert vectors with payloads."""
        self._validate_tenant_id(tenant_id)
        
        if not self._available:
            raise RuntimeError("Qdrant not available")
        
        try:
            from qdrant_client.models import PointStruct
            
            points = []
            for id_, vector, payload in zip(ids, vectors, payloads):
                # Add tenant_id to payload for filtering
                enriched_payload = {**payload, "tenant_id": tenant_id}
                points.append(PointStruct(id=id_, vector=vector, payload=enriched_payload))
            
            result = await self._client.upsert(
                collection_name=self.collection_name,
                points=points,
            )
            
            return result.status == "completed"
        except Exception as e:
            raise RuntimeError(f"Qdrant upsert failed: {e}")
    
    async def search(
        self,
        vector: list[float],
        limit: int,
        tenant_id: str,
        filter_dict: dict[str, Any] | None = None,
    ) -> list[tuple[str, float, dict[str, Any]]]:
        """Search for similar vectors with tenant isolation."""
        self._validate_tenant_id(tenant_id)
        
        if not self._available:
            return []
        
        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            
            # Build filter with tenant isolation
            conditions = [
                FieldCondition(
                    key="tenant_id",
                    match=MatchValue(value=tenant_id),
                )
            ]
            
            # Add additional filters
            if filter_dict:
                for key, value in filter_dict.items():
                    conditions.append(
                        FieldCondition(
                            key=key,
                            match=MatchValue(value=value),
                        )
                    )
            
            qdrant_filter = Filter(must=conditions) if conditions else None
            
            results = await self._client.search(
                collection_name=self.collection_name,
                query_vector=vector,
                query_filter=qdrant_filter,
                limit=limit,
            )
            
            return [
                (str(result.id), result.score, result.payload or {})
                for result in results
            ]
        except Exception:
            return []
    
    async def delete(self, ids: list[str], tenant_id: str) -> bool:
        """Delete vectors by ID."""
        self._validate_tenant_id(tenant_id)
        
        if not self._available:
            return False
        
        try:
            result = await self._client.delete(
                collection_name=self.collection_name,
                points_selector=ids,
            )
            return result.status == "completed"
        except Exception:
            return False
    
    def is_available(self) -> bool:
        """Check if Qdrant is available for queries."""
        return self._available and self._initialized


__all__ = ["QdrantVectorStore"]
