"""
Query analysis schemas.

Defines the structure for query intent analysis, complexity assessment,
and execution level routing.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class QueryIntent(str, Enum):
    """Primary intent of the query."""
    
    LOOKUP = "lookup"  # Simple fact lookup
    DEFINITION = "definition"  # What is X?
    EXPLANATION = "explanation"  # Why/How questions
    COMPARISON = "comparison"  # Compare X and Y
    ANALYSIS = "analysis"  # Complex analytical question
    RESEARCH = "research"  # Open-ended research
    VERIFICATION = "verification"  # Verify a claim
    CALCULATION = "calculation"  # Mathematical computation
    PROCEDURE = "procedure"  # How-to steps
    TEMPORAL = "temporal"  # Time-based question
    CAUSAL = "causal"  # Cause-effect relationship


class ExecutionLevel(str, Enum):
    """Execution level for query processing."""
    
    L0 = "L0"  # Deterministic - exact lookup, calculation
    L1 = "L1"  # Fast RAG - simple retrieval + answer
    L2 = "L2"  # Analytical RAG - multi-source fusion
    L3 = "L3"  # Cognitive Research - full reasoning pipeline


class QueryAnalysis(BaseModel):
    """
    Result of query analysis phase.
    
    This object determines how the query will be routed and processed.
    Analysis uses both deterministic heuristics and optional LLM enhancement.
    
    Attributes:
        original_query: The original user query
        intent: Primary intent classification
        domain: Detected domain (e.g., finance, medical, legal)
        entities: Extracted entities
        complexity: Complexity score (0-1)
        ambiguity: Ambiguity score (0-1)
        risk: Risk score (0-1) for sensitive topics
        time_sensitive: Whether query requires current information
        requires_exact_match: Whether exact matching is needed
        requires_graph: Whether graph traversal is beneficial
        requires_memory: Whether historical context is needed
        requires_external_data: Whether external sources are needed
        requires_multi_hop: Whether multi-hop retrieval is needed
        requires_verification: Whether verification is mandatory
        execution_level: Recommended execution level
        confidence: Confidence in this analysis (0-1)
        metadata: Additional analysis metadata
    """
    
    # Input
    original_query: str = Field(..., min_length=1)
    
    # Classification
    intent: QueryIntent = Field(default=QueryIntent.EXPLANATION)
    domain: str | None = Field(default=None, description="Detected domain")
    entities: list[str] = Field(default_factory=list, description="Extracted entities")
    
    # Scoring
    complexity: float = Field(default=0.5, ge=0.0, le=1.0, description="Complexity score")
    ambiguity: float = Field(default=0.5, ge=0.0, le=1.0, description="Ambiguity score")
    risk: float = Field(default=0.0, ge=0.0, le=1.0, description="Risk score")
    
    # Requirements flags
    time_sensitive: bool = Field(default=False)
    requires_exact_match: bool = Field(default=False)
    requires_graph: bool = Field(default=False)
    requires_memory: bool = Field(default=False)
    requires_external_data: bool = Field(default=False)
    requires_multi_hop: bool = Field(default=False)
    requires_verification: bool = Field(default=True)
    
    # Routing
    execution_level: ExecutionLevel = Field(default=ExecutionLevel.L1)
    
    # Meta
    confidence: float = Field(default=0.8, ge=0.0, le=1.0, description="Analysis confidence")
    metadata: dict[str, Any] = Field(default_factory=dict)
    
    def should_use_fast_path(self, threshold: float = 0.30) -> bool:
        """Determine if query should use fast path (L0/L1)."""
        return self.complexity <= threshold
    
    def should_use_analytical_path(self, threshold: float = 0.60) -> bool:
        """Determine if query should use analytical path (L2)."""
        return threshold < self.complexity <= 0.80
    
    def should_use_cognitive_path(self) -> bool:
        """Determine if query requires full cognitive pipeline (L3)."""
        return (
            self.complexity > 0.80 or
            self.requires_multi_hop or
            self.intent in {QueryIntent.RESEARCH, QueryIntent.ANALYSIS}
        )
    
    def determine_execution_level(
        self,
        fast_threshold: float = 0.30,
        analytical_threshold: float = 0.60,
    ) -> ExecutionLevel:
        """
        Determine appropriate execution level based on analysis.
        
        This implements the adaptive routing policy.
        """
        # L0: Deterministic queries
        if self.requires_exact_match and not self.requires_multi_hop:
            if self.intent in {QueryIntent.LOOKUP, QueryIntent.CALCULATION}:
                return ExecutionLevel.L0
        
        # L3: Cognitive research
        if self.should_use_cognitive_path():
            return ExecutionLevel.L3
        
        # L2: Analytical
        if self.should_use_analytical_path(analytical_threshold):
            return ExecutionLevel.L2
        
        # L1: Fast RAG (default)
        return ExecutionLevel.L1
    
    @classmethod
    def from_query(cls, query: str) -> "QueryAnalysis":
        """Create minimal QueryAnalysis from raw query."""
        return cls(original_query=query)


__all__ = ["QueryIntent", "ExecutionLevel", "QueryAnalysis"]
