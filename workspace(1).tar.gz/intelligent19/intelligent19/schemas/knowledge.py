"""
Canonical Knowledge Object schema.

This is the core representation of all knowledge in the system.
All storage backends (vector, graph, lexical) are derived projections of this object.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator


class KnowledgeType(str, Enum):
    """Type of knowledge content."""
    
    DOCUMENT = "document"
    FACT = "fact"
    ENTITY = "entity"
    EVENT = "event"
    PROCEDURE = "procedure"
    POLICY = "policy"
    METADATA = "metadata"


class TrustLevel(str, Enum):
    """Trust level for knowledge sources."""
    
    VERIFIED = "verified"  # Official, audited sources
    AUTHORITATIVE = "authoritative"  # Recognized authorities
    COMMUNITY = "community"  # Community-contributed
    UNVERIFIED = "unverified"  # Not yet verified
    LOW_TRUST = "low_trust"  # Low confidence sources


class CanonicalKnowledgeObject(BaseModel):
    """
    Canonical representation of knowledge in the system.
    
    This object serves as the single source of truth. All storage systems
    (vector DB, graph DB, BM25 index, cache) are derived projections of this object.
    
    Attributes:
        id: Unique identifier (ULID/UUID)
        tenant_id: Tenant isolation identifier
        source_id: Original source identifier
        content_hash: SHA-256 hash of content for deduplication
        entity_ids: Linked entity identifiers
        content: The actual knowledge content
        knowledge_type: Type classification
        created_at: Creation timestamp
        valid_from: Validity start (for temporal knowledge)
        valid_until: Validity end (for temporal knowledge)
        authority_score: Computed authority score (0-1)
        trust_level: Trust classification
        version: Version number for updates
        embedding_version: Embedding model version if embedded
        provenance_id: Link to provenance record
        metadata: Additional structured metadata
    """
    
    # Identity
    id: str = Field(default_factory=lambda: str(uuid4()), description="Unique identifier")
    tenant_id: str = Field(..., min_length=1, description="Tenant isolation ID")
    source_id: str = Field(..., min_length=1, description="Source system ID")
    content_hash: str = Field(..., min_length=64, description="SHA-256 content hash")
    
    # Links
    entity_ids: list[str] = Field(default_factory=list, description="Linked entity IDs")
    
    # Content
    content: str = Field(..., min_length=1, description="Knowledge content")
    knowledge_type: KnowledgeType = Field(default=KnowledgeType.DOCUMENT)
    
    # Temporal
    created_at: datetime = Field(default_factory=datetime.utcnow)
    valid_from: datetime | None = Field(default=None, description="Validity start")
    valid_until: datetime | None = Field(default=None, description="Validity end")
    superseded_by: str | None = Field(default=None, description="ID of superseding version")
    
    # Authority
    authority_score: float = Field(default=0.5, ge=0.0, le=1.0, description="Authority score")
    trust_level: TrustLevel = Field(default=TrustLevel.UNVERIFIED)
    
    # Versioning
    version: int = Field(default=1, ge=1, description="Version number")
    embedding_version: str | None = Field(default=None, description="Embedding model version")
    
    # Provenance
    provenance_id: str | None = Field(default=None, description="Provenance record ID")
    
    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    
    @field_validator("content_hash")
    @classmethod
    def validate_content_hash(cls, v: str) -> str:
        """Validate content hash is proper SHA-256 format."""
        if len(v) != 64:
            raise ValueError("Content hash must be 64 characters (SHA-256)")
        try:
            bytes.fromhex(v)
        except ValueError:
            raise ValueError("Content hash must be valid hexadecimal")
        return v
    
    @field_validator("authority_score")
    @classmethod
    def validate_authority_score(cls, v: float) -> float:
        """Ensure authority score is in valid range."""
        if not (0.0 <= v <= 1.0):
            raise ValueError("Authority score must be between 0 and 1")
        return v
    
    def is_valid_at(self, timestamp: datetime) -> bool:
        """Check if knowledge is valid at given timestamp."""
        if self.valid_from and timestamp < self.valid_from:
            return False
        if self.valid_until and timestamp > self.valid_until:
            return False
        return True
    
    def is_current(self) -> bool:
        """Check if knowledge is currently valid."""
        return self.is_valid_at(datetime.utcnow())
    
    def mark_superseded(self, new_version_id: str) -> None:
        """Mark this object as superseded by a newer version."""
        self.superseded_by = new_version_id
    
    def compute_content_hash(content: str) -> str:
        """Compute SHA-256 hash of content."""
        import hashlib
        return hashlib.sha256(content.encode("utf-8")).hexdigest()
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "id": "01HXYZ123ABC",
                "tenant_id": "tenant-001",
                "source_id": "doc-456",
                "content_hash": "a1b2c3...",
                "entity_ids": ["entity-1", "entity-2"],
                "content": "Knowledge content here...",
                "knowledge_type": "document",
                "created_at": "2024-01-01T00:00:00Z",
                "valid_from": "2024-01-01T00:00:00Z",
                "valid_until": None,
                "authority_score": 0.85,
                "trust_level": "authoritative",
                "version": 1,
                "embedding_version": "text-embedding-3-large",
                "provenance_id": "prov-789",
                "metadata": {"language": "en", "domain": "finance"}
            }
        }
    }


__all__ = ["CanonicalKnowledgeObject", "KnowledgeType", "TrustLevel"]
