"""
Evidence and Claim schemas for INTELLIGENT19 V5 - PHASE 2 Hardened.

Defines the structure for evidence tracking, claim verification,
and evidence graph relationships.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class EvidenceRelationship(str, Enum):
    """Relationship type between evidence and claims."""

    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    NEUTRAL = "neutral"
    UNKNOWN = "unknown"
    IRRELEVANT = "irrelevant"
    DERIVED_FROM = "derived_from"
    MENTIONS = "mentions"
    ABOUT = "about"
    VALID_DURING = "valid_during"
    SUPERSEDES = "supersedes"
    RELATED_TO = "related_to"
    CAUSED_BY = "caused_by"


class ClaimVerificationStatus(str, Enum):
    """Status of claim verification."""

    PENDING = "pending"
    EVALUATING = "evaluating"
    SUPPORTED = "supported"
    PARTIALLY_SUPPORTED = "partially_supported"
    CONTRADICTED = "contradicted"
    UNVERIFIED = "unverified"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"
    VERIFIED = "verified"
    UNCERTAIN = "uncertain"
    WEAKLY_SUPPORTED = "weakly_supported"
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"


class EvidenceAssessment(BaseModel):
    """Assessment of evidence against a claim."""

    relation: EvidenceRelationship = Field(default=EvidenceRelationship.UNKNOWN)
    relevance: float = Field(default=0.0, ge=0.0, le=1.0)
    entailment: float = Field(default=0.0, ge=0.0, le=1.0)
    contradiction: float = Field(default=0.0, ge=0.0, le=1.0)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    explanation: str | None = Field(default=None)


class Evidence(BaseModel):
    """Evidence object representing a retrieved piece of information."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(default="default", min_length=1)
    source_id: str = Field(..., min_length=1)
    content: str = Field(..., min_length=1)
    evidence_type: str = Field(default="extracted")
    relevance_score: float = Field(default=0.5, ge=0.0, le=1.0)
    authority_score: float = Field(default=0.5, ge=0.0, le=1.0)
    freshness_score: float = Field(default=0.5, ge=0.0, le=1.0)
    relationship: EvidenceRelationship = Field(default=EvidenceRelationship.UNKNOWN)
    provenance_id: str | None = Field(default=None)
    knowledge_object_id: str | None = Field(default=None)
    chunk_id: str | None = Field(default=None)
    document_id: str | None = Field(default=None)
    retrieved_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True

    def combined_score(
        self,
        relevance_weight: float = 0.5,
        authority_weight: float = 0.3,
        freshness_weight: float = 0.2,
    ) -> float:
        return (
            self.relevance_score * relevance_weight
            + self.authority_score * authority_weight
            + self.freshness_score * freshness_weight
        )


class Claim(BaseModel):
    """Claim extracted from generated answer or user query."""

    claim_id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(default="default", min_length=1)
    text: str = Field(..., min_length=1)
    claim_type: str = Field(default="fact")
    content_hash: str | None = Field(default=None)
    evidence_ids: list[str] = Field(default_factory=list)
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    contradicting_evidence_ids: list[str] = Field(default_factory=list)
    support_score: float = Field(default=0.0, ge=0.0, le=1.0)
    contradiction_score: float = Field(default=0.0, ge=0.0, le=1.0)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    verification_status: ClaimVerificationStatus = Field(
        default=ClaimVerificationStatus.PENDING
    )
    verified_at: datetime | None = Field(default=None)
    version: int = Field(default=1)
    superseded_by: str | None = Field(default=None)
    metadata: dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True

    def add_supporting_evidence(self, evidence_id: str) -> None:
        if evidence_id not in self.supporting_evidence_ids:
            self.supporting_evidence_ids.append(evidence_id)
            if evidence_id not in self.evidence_ids:
                self.evidence_ids.append(evidence_id)

    def add_contradicting_evidence(self, evidence_id: str) -> None:
        if evidence_id not in self.contradicting_evidence_ids:
            self.contradicting_evidence_ids.append(evidence_id)
            if evidence_id not in self.evidence_ids:
                self.evidence_ids.append(evidence_id)

    def update_verification_status(self) -> None:
        if not self.evidence_ids:
            self.verification_status = ClaimVerificationStatus.INSUFFICIENT_EVIDENCE
            return

        num_support = len(self.supporting_evidence_ids)
        num_contradict = len(self.contradicting_evidence_ids)
        total_support = num_support * self.support_score
        total_contradiction = num_contradict * self.contradiction_score

        if num_contradict > 0 and total_contradiction > total_support * 1.5:
            self.verification_status = ClaimVerificationStatus.CONTRADICTED
        elif num_support > 0 and total_support > 0.7 and total_contradiction < 0.3:
            self.verification_status = ClaimVerificationStatus.SUPPORTED
        elif num_support > 0 and total_support > 0.5 and total_contradiction < 0.5:
            self.verification_status = ClaimVerificationStatus.PARTIALLY_SUPPORTED
        elif total_support > total_contradiction:
            self.verification_status = ClaimVerificationStatus.UNVERIFIED
        else:
            self.verification_status = ClaimVerificationStatus.INSUFFICIENT_EVIDENCE

        self.verified_at = datetime.now(timezone.utc)
        self.version += 1

    def merge_verification(self, other: "Claim") -> None:
        for eid in other.supporting_evidence_ids:
            self.add_supporting_evidence(eid)
        for eid in other.contradicting_evidence_ids:
            self.add_contradicting_evidence(eid)
        if other.support_score > 0:
            self.support_score = (self.support_score + other.support_score) / 2
        if other.contradiction_score > 0:
            self.contradiction_score = (self.contradiction_score + other.contradiction_score) / 2
        self.confidence = max(self.confidence, other.confidence)
        self.update_verification_status()


class ContradictionType(str, Enum):
    """Types of contradictions."""

    SEMANTIC = "semantic"
    TEMPORAL = "temporal"
    ENTITY_MISMATCH = "entity_mismatch"
    SCOPE_MISMATCH = "scope_mismatch"
    SOURCE_DISAGREEMENT = "source_disagreement"


class ContradictionDetection(BaseModel):
    """Result of contradiction detection."""

    item_a_id: str
    item_b_id: str
    contradiction_type: ContradictionType = Field(default=ContradictionType.SEMANTIC)
    relationship: EvidenceRelationship = Field(default=EvidenceRelationship.CONTRADICTS)
    severity: float = Field(default=0.0, ge=0.0, le=1.0)
    resolution: str | None = Field(default=None)
    resolution_outcome: str | None = Field(default=None)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    explanation: str | None = Field(default=None)
    tenant_id: str = Field(default="default")

    class Config:
        arbitrary_types_allowed = True


class VerificationRecord(BaseModel):
    """Record of a verification attempt."""

    record_id: str = Field(default_factory=lambda: str(uuid4()))
    claim_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    verifier_type: str
    result: ClaimVerificationStatus
    evidence_used: list[str] = Field(default_factory=list)
    scores: dict[str, float] = Field(default_factory=dict)
    explanation: str | None = Field(default=None)
    metadata: dict[str, Any] = Field(default_factory=dict)


__all__ = [
    "EvidenceRelationship",
    "ClaimVerificationStatus",
    "ContradictionType",
    "EvidenceAssessment",
    "Evidence",
    "Claim",
    "ContradictionDetection",
    "VerificationRecord",
]
