"""
Response schemas.

Defines the structure for system responses including multi-dimensional
confidence vectors and response metadata.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class ResponseStatus(str, Enum):
    """Status of the response generation."""
    
    SUCCESS = "success"
    PARTIAL = "partial"  # Some components failed
    DEGRADED = "degraded"  # Running in degraded mode
    FAILED = "failed"
    BLOCKED = "blocked"  # Blocked by verification/security


class ExecutionMode(str, Enum):
    """Execution mode used for generating response."""
    
    DETERMINISTIC = "deterministic"  # L0
    FAST_RAG = "fast_rag"  # L1
    ANALYTICAL = "analytical"  # L2
    COGNITIVE = "cognitive"  # L3


class ConfidenceVector(BaseModel):
    """
    Multi-dimensional confidence scores.
    
    Instead of a single confidence number, we track confidence
    across multiple dimensions to enable better decision-making.
    
    Attributes:
        retrieval: Confidence in retrieved evidence (0-1)
        evidence: Confidence in evidence quality and coverage (0-1)
        source: Confidence in source authority and trust (0-1)
        reasoning: Confidence in reasoning process (0-1)
        temporal: Confidence in temporal validity (0-1)
        consistency: Confidence in internal consistency (0-1)
        verification: Confidence from verification checks (0-1)
    """
    
    retrieval: float = Field(default=0.0, ge=0.0, le=1.0)
    evidence: float = Field(default=0.0, ge=0.0, le=1.0)
    source: float = Field(default=0.0, ge=0.0, le=1.0)
    reasoning: float = Field(default=0.0, ge=0.0, le=1.0)
    temporal: float = Field(default=0.0, ge=0.0, le=1.0)
    consistency: float = Field(default=0.0, ge=0.0, le=1.0)
    verification: float = Field(default=0.0, ge=0.0, le=1.0)
    
    def overall(self, weights: dict[str, float] | None = None) -> float:
        """
        Compute weighted overall confidence.
        
        Default weights emphasize evidence and verification.
        """
        if weights is None:
            weights = {
                "retrieval": 0.15,
                "evidence": 0.25,
                "source": 0.10,
                "reasoning": 0.15,
                "temporal": 0.10,
                "consistency": 0.10,
                "verification": 0.15,
            }
        
        total = 0.0
        weight_sum = 0.0
        
        for field_name, weight in weights.items():
            value = getattr(self, field_name, 0.0)
            total += value * weight
            weight_sum += weight
        
        return total / weight_sum if weight_sum > 0 else 0.0
    
    def weakest_dimension(self) -> tuple[str, float]:
        """Return the dimension with lowest confidence."""
        dimensions = [
            ("retrieval", self.retrieval),
            ("evidence", self.evidence),
            ("source", self.source),
            ("reasoning", self.reasoning),
            ("temporal", self.temporal),
            ("consistency", self.consistency),
            ("verification", self.verification),
        ]
        return min(dimensions, key=lambda x: x[1])
    
    def should_block_answer(self, threshold: float = 0.60) -> bool:
        """Determine if answer should be blocked due to low confidence."""
        return self.overall() < threshold or self.verification < 0.50


class Citation(BaseModel):
    """Citation for a piece of evidence."""
    
    citation_id: str = Field(default_factory=lambda: str(uuid4()))
    evidence_id: str
    source_id: str
    text: str
    position_in_response: int | None = None


class ResponseMetadata(BaseModel):
    """
    Metadata about response generation.
    
    Provides full observability into how the response was generated.
    """
    
    request_id: str = Field(..., description="Unique request identifier")
    trace_id: str | None = Field(default=None, description="Distributed trace ID")
    tenant_id: str = Field(..., description="Tenant identifier")
    
    # Execution
    execution_level: ExecutionMode = Field(default=ExecutionMode.FAST_RAG)
    execution_time_ms: float = Field(default=0.0, ge=0.0)
    
    # Resource usage
    llm_calls: int = Field(default=0, ge=0)
    tool_calls: int = Field(default=0, ge=0)
    retrieval_rounds: int = Field(default=0, ge=0)
    tokens_used: int = Field(default=0, ge=0)
    
    # Retrieval stats
    documents_retrieved: int = Field(default=0, ge=0)
    reranker_latency_ms: float | None = Field(default=None, ge=0.0)
    
    # Recovery
    retry_count: int = Field(default=0, ge=0)
    recovery_count: int = Field(default=0, ge=0)
    
    # Mode flags
    degraded_mode: bool = Field(default=False)
    cache_hit: bool = Field(default=False)
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Response(BaseModel):
    """
    Complete response from INTELLIGENT19 system.
    
    Attributes:
        id: Unique response identifier
        query: Original user query
        answer: Generated answer text
        status: Response status
        confidence: Multi-dimensional confidence vector
        citations: List of citations
        claims: List of extracted claims
        metadata: Response metadata
        warnings: Any warnings or caveats
        follow_up_questions: Suggested follow-up questions
        raw_data: Raw intermediate data (optional, for debugging)
    """
    
    # Identity
    id: str = Field(default_factory=lambda: str(uuid4()))
    query: str = Field(..., min_length=1)
    
    # Content
    answer: str = Field(..., min_length=1)
    status: ResponseStatus = Field(default=ResponseStatus.SUCCESS)
    
    # Confidence
    confidence: ConfidenceVector = Field(default_factory=ConfidenceVector)
    
    # Evidence
    citations: list[Citation] = Field(default_factory=list)
    claim_ids: list[str] = Field(default_factory=list)
    
    # Metadata
    metadata: ResponseMetadata | None = Field(default=None)
    
    # Additional info
    warnings: list[str] = Field(default_factory=list)
    follow_up_questions: list[str] = Field(default_factory=list)
    
    # Debug (only in development mode)
    raw_data: dict[str, Any] | None = Field(default=None)
    
    def add_citation(
        self,
        evidence_id: str,
        source_id: str,
        text: str,
        position: int | None = None,
    ) -> Citation:
        """Add a citation to the response."""
        citation = Citation(
            evidence_id=evidence_id,
            source_id=source_id,
            text=text,
            position_in_response=position,
        )
        self.citations.append(citation)
        return citation
    
    def add_warning(self, warning: str) -> None:
        """Add a warning message."""
        self.warnings.append(warning)
    
    def mark_degraded(self) -> None:
        """Mark response as generated in degraded mode."""
        if self.metadata:
            self.metadata.degraded_mode = True
        self.status = ResponseStatus.DEGRADED
        self.add_warning("Response generated in degraded mode due to system constraints")
    
    def has_sufficient_confidence(self, threshold: float = 0.60) -> bool:
        """Check if response has sufficient confidence."""
        return not self.confidence.should_block_answer(threshold)


class ErrorResponse(BaseModel):
    """Error response structure."""
    
    error_code: str
    message: str
    details: dict[str, Any] | None = None
    request_id: str | None = None
    recoverable: bool = False
    suggested_action: str | None = None


__all__ = [
    "ResponseStatus",
    "ExecutionMode",
    "ConfidenceVector",
    "Citation",
    "ResponseMetadata",
    "Response",
    "ErrorResponse",
]
