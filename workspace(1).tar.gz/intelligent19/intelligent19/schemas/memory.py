"""
Memory schemas.

Defines the structure for multi-layer memory system including
working, episodic, semantic, procedural, and strategic memory.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class MemoryType(str, Enum):
    """Type of memory in the cognitive architecture."""
    
    WORKING = "working"  # Short-term active context
    EPISODIC = "episodic"  # Specific experiences/events
    SEMANTIC = "semantic"  # General knowledge/facts
    PROCEDURAL = "procedural"  # How-to knowledge/skills
    STRATEGIC = "strategic"  # Meta-knowledge about problem-solving


class MemoryState(str, Enum):
    """Lifecycle state of a memory entry."""
    
    CANDIDATE = "candidate"  # Newly observed, not validated
    ACTIVE = "active"  # Validated and actively used
    REINFORCED = "reinforced"  # Strengthened through use
    STALE = "stale"  # Not accessed recently
    ARCHIVED = "archived"  # Moved to long-term storage
    INVALIDATED = "invalidated"  # Contradicted or obsolete


class MemoryEntry(BaseModel):
    """
    Memory entry in the multi-layer memory system.
    
    Attributes:
        id: Unique identifier
        tenant_id: Tenant isolation ID
        memory_type: Type of memory
        content: Memory content
        state: Current lifecycle state
        importance: Importance score (0-1)
        confidence: Confidence in memory accuracy (0-1)
        access_count: Number of times accessed
        last_accessed: Timestamp of last access
        created_at: Creation timestamp
        decay_rate: Rate at which memory decays (0-1 per day)
        ttl_days: Time-to-live in days
        contradiction_count: Number of contradictions detected
        source_quality: Quality score of source (0-1)
        metadata: Additional metadata
    """
    
    # Identity
    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(..., min_length=1)
    
    # Content
    memory_type: MemoryType = Field(default=MemoryType.WORKING)
    content: str = Field(..., min_length=1)
    content_hash: str | None = Field(default=None)
    
    # State
    state: MemoryState = Field(default=MemoryState.CANDIDATE)
    
    # Scoring
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    source_quality: float = Field(default=0.5, ge=0.0, le=1.0)
    
    # Access tracking
    access_count: int = Field(default=0, ge=0)
    last_accessed: datetime | None = Field(default=None)
    
    # Temporal
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime | None = Field(default=None)
    
    # Decay
    decay_rate: float = Field(default=0.01, ge=0.0, le=1.0)  # Per day
    ttl_days: int | None = Field(default=30, ge=1)
    
    # Validation
    contradiction_count: int = Field(default=0, ge=0)
    validation_outcomes: list[dict[str, Any]] = Field(default_factory=list)
    
    # Links
    related_memory_ids: list[str] = Field(default_factory=list)
    source_knowledge_ids: list[str] = Field(default_factory=list)
    
    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)
    
    def touch(self) -> None:
        """Update last accessed timestamp and increment access count."""
        self.last_accessed = datetime.utcnow()
        self.access_count += 1
    
    def compute_current_importance(self) -> float:
        """
        Compute current importance considering decay and access patterns.
        
        Formula: base_importance * (1 - decay) + access_bonus
        """
        if self.created_at:
            age_days = (datetime.utcnow() - self.created_at).days
            decay_factor = max(0, 1 - (self.decay_rate * age_days))
        else:
            decay_factor = 1.0
        
        # Access bonus: more accesses = higher importance
        access_bonus = min(0.3, self.access_count * 0.01)
        
        return min(1.0, self.importance * decay_factor + access_bonus)
    
    def is_expired(self) -> bool:
        """Check if memory has expired."""
        if self.expires_at and datetime.utcnow() > self.expires_at:
            return True
        if self.ttl_days:
            age_days = (datetime.utcnow() - self.created_at).days
            if age_days > self.ttl_days:
                return True
        return False
    
    def should_consolidate(self) -> bool:
        """Determine if memory should be consolidated to long-term storage."""
        if self.state != MemoryState.ACTIVE:
            return False
        
        # High importance and confidence
        if self.compute_current_importance() > 0.7 and self.confidence > 0.8:
            return True
        
        # Frequently accessed
        if self.access_count > 10:
            return True
        
        return False
    
    def add_contradiction(self) -> None:
        """Record a contradiction."""
        self.contradiction_count += 1
        if self.contradiction_count >= 3:
            self.state = MemoryState.INVALIDATED
    
    def reinforce(self, outcome_score: float) -> None:
        """
        Reinforce memory based on positive outcome.
        
        Args:
            outcome_score: Score from 0-1 indicating success of using this memory
        """
        self.validation_outcomes.append({
            "score": outcome_score,
            "timestamp": datetime.utcnow().isoformat(),
        })
        
        # Update confidence based on outcomes
        if self.validation_outcomes:
            avg_outcome = sum(o["score"] for o in self.validation_outcomes) / len(self.validation_outcomes)
            self.confidence = min(1.0, (self.confidence + avg_outcome) / 2)
        
        if outcome_score > 0.7:
            self.state = MemoryState.REINFORCED
            self.importance = min(1.0, self.importance + 0.05)


class WorkingMemory(MemoryEntry):
    """Working memory entry for active context."""
    
    memory_type: MemoryType = Field(default=MemoryType.WORKING)
    ttl_minutes: int = Field(default=30, ge=1)
    context_window_position: int | None = Field(default=None)


class EpisodicMemory(MemoryEntry):
    """Episodic memory for specific experiences."""
    
    memory_type: MemoryType = Field(default=MemoryType.EPISODIC)
    event_timestamp: datetime | None = Field(default=None)
    location_context: str | None = Field(default=None)
    participants: list[str] = Field(default_factory=list)
    emotional_valence: float | None = Field(default=None, ge=-1.0, le=1.0)


class SemanticMemory(MemoryEntry):
    """Semantic memory for general knowledge."""
    
    memory_type: MemoryType = Field(default=MemoryType.SEMANTIC)
    concept: str | None = Field(default=None)
    category: str | None = Field(default=None)
    relationships: list[dict[str, str]] = Field(default_factory=list)


class ProceduralMemory(MemoryEntry):
    """Procedural memory for skills and procedures."""
    
    memory_type: MemoryType = Field(default=MemoryType.PROCEDURAL)
    procedure_name: str | None = Field(default=None)
    steps: list[str] = Field(default_factory=list)
    preconditions: list[str] = Field(default_factory=list)
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)


class StrategicMemory(MemoryEntry):
    """Strategic memory for meta-cognitive knowledge."""
    
    memory_type: MemoryType = Field(default=MemoryType.STRATEGIC)
    strategy_name: str | None = Field(default=None)
    applicable_scenarios: list[str] = Field(default_factory=list)
    effectiveness_score: float | None = Field(default=None, ge=0.0, le=1.0)
    lessons_learned: list[str] = Field(default_factory=list)


__all__ = [
    "MemoryType",
    "MemoryState",
    "MemoryEntry",
    "WorkingMemory",
    "EpisodicMemory",
    "SemanticMemory",
    "ProceduralMemory",
    "StrategicMemory",
]
