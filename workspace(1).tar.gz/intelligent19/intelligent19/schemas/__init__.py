"""
Core schemas for INTELLIGENT19 platform.

These schemas define the canonical data structures used throughout the system.
All schemas use Pydantic for validation and type safety.
"""

from .knowledge import CanonicalKnowledgeObject, KnowledgeType, TrustLevel
from .query import QueryAnalysis, QueryIntent, ExecutionLevel
from .evidence import Evidence, EvidenceRelationship, Claim, ClaimVerificationStatus
from .memory import MemoryEntry, MemoryType, MemoryState
from .response import Response, ResponseMetadata, ConfidenceVector

__all__ = [
    # Knowledge
    "CanonicalKnowledgeObject",
    "KnowledgeType",
    "TrustLevel",
    # Query
    "QueryAnalysis",
    "QueryIntent",
    "ExecutionLevel",
    # Evidence
    "Evidence",
    "EvidenceRelationship",
    "Claim",
    "ClaimVerificationStatus",
    # Memory
    "MemoryEntry",
    "MemoryType",
    "MemoryState",
    # Response
    "Response",
    "ResponseMetadata",
    "ConfidenceVector",
]
