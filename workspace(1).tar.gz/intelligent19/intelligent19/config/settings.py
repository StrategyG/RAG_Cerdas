"""
Settings management using Pydantic Settings.

All configuration parameters are loaded from environment variables or YAML files.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class RetrievalSettings(BaseSettings):
    """Retrieval configuration."""

    dense_top_k: int = Field(default=30, description="Top K for dense retrieval")
    lexical_top_k: int = Field(default=30, description="Top K for lexical/BM25 retrieval")
    graph_top_k: int = Field(default=20, description="Top K for graph retrieval")
    fusion_top_k: int = Field(default=20, description="Top K after fusion")
    rerank_top_k: int = Field(default=8, description="Top K after reranking")
    rrf_k: int = Field(default=60, description="RRF constant k")
    
    model_config = SettingsConfigDict(env_prefix="RETRIEVAL_", extra="ignore")


class RouterSettings(BaseSettings):
    """Query router configuration."""

    fast_path_threshold: float = Field(default=0.30, description="Threshold for L0/L1 routing")
    analytical_threshold: float = Field(default=0.60, description="Threshold for L2 routing")
    use_heuristics: bool = Field(default=True, description="Use deterministic heuristics")
    
    model_config = SettingsConfigDict(env_prefix="ROUTER_", extra="ignore")


class ReasoningSettings(BaseSettings):
    """Reasoning engine configuration."""

    max_hops: int = Field(default=4, description="Maximum reasoning hops")
    max_hypotheses: int = Field(default=5, description="Maximum hypotheses to consider")
    enable_causal: bool = Field(default=True, description="Enable causal reasoning")
    enable_temporal: bool = Field(default=True, description="Enable temporal reasoning")
    
    model_config = SettingsConfigDict(env_prefix="REASONING_", extra="ignore")


class VerificationSettings(BaseSettings):
    """Verification configuration."""

    minimum_evidence_score: float = Field(default=0.70, description="Minimum evidence score")
    minimum_groundedness: float = Field(default=0.80, description="Minimum groundedness score")
    require_citations: bool = Field(default=True, description="Require citations in answers")
    max_verification_rounds: int = Field(default=2, description="Maximum verification attempts")
    
    model_config = SettingsConfigDict(env_prefix="VERIFICATION_", extra="ignore")


class RuntimeSettings(BaseSettings):
    """Runtime budget and limits."""

    max_runtime_ms: int = Field(default=15000, description="Maximum request runtime in ms")
    max_llm_calls: int = Field(default=8, description="Maximum LLM calls per request")
    max_tool_calls: int = Field(default=10, description="Maximum tool calls per request")
    max_retrieval_rounds: int = Field(default=3, description="Maximum retrieval rounds")
    max_tokens: int = Field(default=12000, description="Maximum tokens per request")
    max_cost: float = Field(default=0.05, description="Maximum cost per request in USD")
    max_recovery_loops: int = Field(default=2, description="Maximum recovery loops")
    
    model_config = SettingsConfigDict(env_prefix="RUNTIME_", extra="ignore")


class StorageSettings(BaseSettings):
    """Storage backend configuration."""

    # PostgreSQL
    postgres_host: str = Field(default="localhost", description="PostgreSQL host")
    postgres_port: int = Field(default=5432, description="PostgreSQL port")
    postgres_db: str = Field(default="intelligent19", description="PostgreSQL database")
    postgres_user: str = Field(default="intelligent19", description="PostgreSQL user")
    postgres_password: str = Field(default="changeme", description="PostgreSQL password")
    
    # Qdrant
    qdrant_host: str = Field(default="localhost", description="Qdrant host")
    qdrant_port: int = Field(default=6333, description="Qdrant port")
    qdrant_collection: str = Field(default="knowledge", description="Qdrant collection name")
    
    # Redis
    redis_host: str = Field(default="localhost", description="Redis host")
    redis_port: int = Field(default=6379, description="Redis port")
    redis_db: int = Field(default=0, description="Redis database")
    
    model_config = SettingsConfigDict(env_prefix="STORAGE_", extra="ignore")


class SecuritySettings(BaseSettings):
    """Security configuration."""

    enable_prompt_injection_detection: bool = Field(default=True)
    enable_pii_detection: bool = Field(default=True)
    enable_tenant_isolation: bool = Field(default=True)
    max_input_length: int = Field(default=10000, description="Maximum input length")
    allowed_tools: list[str] = Field(default_factory=lambda: ["sql", "python"])
    
    model_config = SettingsConfigDict(env_prefix="SECURITY_", extra="ignore")


class ObservabilitySettings(BaseSettings):
    """Observability configuration."""

    enable_tracing: bool = Field(default=True)
    enable_metrics: bool = Field(default=True)
    log_level: str = Field(default="INFO")
    trace_sample_rate: float = Field(default=1.0)
    
    model_config = SettingsConfigDict(env_prefix="OBSERVABILITY_", extra="ignore")


class Settings(BaseSettings):
    """Main settings class aggregating all configuration sections."""

    # Application
    app_name: str = "INTELLIGENT19"
    app_version: str = "0.1.0"
    environment: str = Field(default="development", description="Environment: development, staging, production")
    debug: bool = Field(default=False)
    
    # Configuration file path
    config_path: str = Field(default="/etc/intelligent19/defaults.yaml", description="Path to YAML config file")
    
    # Sub-settings
    retrieval: RetrievalSettings = Field(default_factory=RetrievalSettings)
    router: RouterSettings = Field(default_factory=RouterSettings)
    reasoning: ReasoningSettings = Field(default_factory=ReasoningSettings)
    verification: VerificationSettings = Field(default_factory=VerificationSettings)
    runtime: RuntimeSettings = Field(default_factory=RuntimeSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)
    observability: ObservabilitySettings = Field(default_factory=ObservabilitySettings)
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )
    
    @classmethod
    def load_from_yaml(cls, yaml_path: str | None = None) -> dict[str, Any]:
        """Load configuration from YAML file."""
        if yaml_path is None:
            yaml_path = os.environ.get("INTELLIGENT19_CONFIG", "/etc/intelligent19/defaults.yaml")
        
        config_path = Path(yaml_path)
        if not config_path.exists():
            return {}
        
        with open(config_path, "r") as f:
            return yaml.safe_load(f) or {}
    
    @field_validator("environment")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        valid_environments = {"development", "staging", "production"}
        if v not in valid_environments:
            raise ValueError(f"Environment must be one of {valid_environments}")
        return v


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    yaml_config = Settings.load_from_yaml()
    
    # Flatten YAML config for pydantic-settings
    flat_config = {}
    for section, values in yaml_config.items():
        if isinstance(values, dict):
            for key, value in values.items():
                flat_config[f"{section.upper()}_{key.upper()}"] = value
        else:
            flat_config[section.upper()] = values
    
    return Settings(**flat_config)


__all__ = ["Settings", "get_settings"]
