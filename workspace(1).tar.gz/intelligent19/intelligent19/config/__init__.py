"""
Configuration management for INTELLIGENT19 platform.

All parameters are configurable via settings.py and YAML files.
No hardcoded values in business logic.
"""

from .settings import Settings, get_settings

__all__ = ["Settings", "get_settings"]
