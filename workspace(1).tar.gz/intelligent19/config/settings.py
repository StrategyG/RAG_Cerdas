"""
Configuration system for INTELLIGENT19 V5.

All parameters are configurable via YAML files, environment variables,
or programmatic overrides. No hardcoded values in business logic.
"""

from __future__ import annotations
import os
import yaml
from pathlib import Path
from typing import Any, Optional
from pydantic import BaseModel, Field
from functools import lru_cache


class RetrievalConfig(BaseModel):
    """Configuration for retrieval subsystem."""
    dense_top_k: int = 30
    lexical_top_k: int = 30
    fusion_top_k: int = 20
    rerank_top_k: int = 8
    
    # RRF parameters
    rrf_k: int = 60
    
    # Score weights (configurable, not hardcoded)
    semantic_weight: float = 0.4
    lexical_weight: float = 0.3
    authority_weight: float = 0.15
    freshness_weight: float = 0.15
    
    # Embedding configuration
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_dimension: int = 384
    
    # Batch sizes
    embedding_batch_size: int = 32


class RouterConfig(BaseModel):
    """Configuration for query routing."""
    fast_path_threshold: float = 0.30
    analytical_threshold: float = 0.60
    
    # Complexity scoring weights
    length_weight: float = 0.2
    entity_count_weight: float = 0.3
    question_word_weight: float = 0.2
    ambiguity_weight: float = 0.3
    
    # Intent detection
    use_llm_for_intent: bool = False
    deterministic_intent_rules: bool = True


class ReasoningConfig(BaseModel):
    """Configuration for reasoning engine."""
    max_hops: int = 4
    max_hypotheses: int = 5
    max_evidence_per_claim: int = 10
    
    # Graph traversal
    max_graph_depth: int = 5
    max_neighbors_per_node: int = 20
    
    # Hypothesis testing
    minimum_support_threshold: float = 0.6
    contradiction_severity_threshold: float = 0.7


class VerificationConfig(BaseModel):
    """Configuration for verification subsystem."""
    minimum_evidence_score: float = 0.70
    minimum_groundedness: float = 0.80
    minimum_consistency_score: float = 0.75
    
    # Hallucination detection
    hallucination_threshold: float = 0.3
    
    # Citation requirements
    require_citations: bool = True
    min_citations_per_claim: int = 1
    
    # Recovery
    max_recovery_loops: int = 2


class RuntimeConfig(BaseModel):
    """Configuration for runtime behavior."""
    max_runtime_ms: int = 15000
    max_llm_calls: int = 8
    max_tool_calls: int = 10
    max_retrieval_rounds: int = 3
    max_tokens: int = 12000
    max_cost: float = 0.05
    
    # Retry configuration
    default_retry_count: int = 3
    retry_backoff_base: float = 2.0
    retry_backoff_max: float = 10.0
    
    # Timeout configuration
    default_timeout_ms: int = 5000
    llm_timeout_ms: int = 10000
    retrieval_timeout_ms: int = 3000
    
    # Circuit breaker
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout_ms: int = 60000


class MemoryConfig(BaseModel):
    """Configuration for memory subsystem."""
    # Layer sizes
    working_memory_capacity: int = 10
    episodic_memory_limit: int = 1000
    semantic_memory_limit: int = 5000
    
    # Decay parameters
    default_decay_rate: float = 0.01
    decay_half_life_days: int = 30
    
    # Consolidation
    consolidation_interval_seconds: int = 300
    consolidation_batch_size: int = 50
    
    # Validation
    memory_validation_required: bool = True
    contradiction_check_enabled: bool = True


class StorageConfig(BaseModel):
    """Configuration for storage backends."""
    # PostgreSQL
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_database: str = "intelligent19"
    postgres_user: str = "intelligent19"
    postgres_password: str = ""
    postgres_pool_size: int = 10
    
    # Qdrant (vector)
    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    qdrant_collection: str = "knowledge"
    
    # Redis (cache)
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    
    # Graph database
    graph_db_url: str = "bolt://localhost:7687"
    graph_db_user: str = "neo4j"
    graph_db_password: str = ""
    
    # BM25 index path
    bm25_index_path: str = "./data/bm25_index"


class SecurityConfig(BaseModel):
    """Configuration for security features."""
    # Prompt injection protection
    enable_injection_detection: bool = True
    injection_threshold: float = 0.8
    
    # PII handling
    enable_pii_detection: bool = True
    pii_redaction: bool = True
    
    # Access control
    enable_tenant_isolation: bool = True
    validate_tenant_on_every_query: bool = True
    
    # Audit
    enable_audit_logging: bool = True
    audit_retention_days: int = 90


class ObservabilityConfig(BaseModel):
    """Configuration for observability."""
    # Logging
    log_level: str = "INFO"
    structured_logging: bool = True
    log_file: Optional[str] = None
    
    # Metrics
    enable_metrics: bool = True
    metrics_port: int = 9090
    
    # Tracing
    enable_tracing: bool = True
    trace_sample_rate: float = 1.0
    
    # Health checks
    health_check_interval_seconds: int = 30


class EvaluationConfig(BaseModel):
    """Configuration for evaluation and benchmarking."""
    # Benchmark datasets
    retrieval_benchmark_dataset: str = "msmarco"
    reasoning_benchmark_dataset: str = "hotpotqa"
    
    # Evaluation frequency
    auto_evaluation_enabled: bool = False
    evaluation_interval_hours: int = 24
    
    # Regression testing
    regression_test_on_deploy: bool = True
    maximum_regression_threshold: float = 0.05


class Config(BaseModel):
    """Main configuration container."""
    # Environment
    environment: str = "development"
    tenant_id: str = "default"
    
    # Subsystem configurations
    retrieval: RetrievalConfig = Field(default_factory=RetrievalConfig)
    router: RouterConfig = Field(default_factory=RouterConfig)
    reasoning: ReasoningConfig = Field(default_factory=ReasoningConfig)
    verification: VerificationConfig = Field(default_factory=VerificationConfig)
    runtime: RuntimeConfig = Field(default_factory=RuntimeConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)
    evaluation: EvaluationConfig = Field(default_factory=EvaluationConfig)
    
    class Config:
        env_prefix = "INTELLIGENT19_"
        env_nested_delimiter = "__"


@lru_cache()
def get_config(config_path: Optional[str] = None) -> Config:
    """
    Get configuration with support for:
    1. YAML file
    2. Environment variables
    3. Default values
    
    Configuration is cached after first load.
    """
    config_dict: dict[str, Any] = {}
    
    # Load from YAML file if provided
    if config_path:
        config_file = Path(config_path)
        if config_file.exists():
            with open(config_file, 'r') as f:
                config_dict = yaml.safe_load(f) or {}
    
    # Try default config location
    if not config_dict:
        default_config = Path(__file__).parent / "defaults.yaml"
        if default_config.exists():
            with open(default_config, 'r') as f:
                config_dict = yaml.safe_load(f) or {}
    
    # Override with environment variables
    for key, value in os.environ.items():
        if key.startswith("INTELLIGENT19_"):
            config_key = key.replace("INTELLIGENT19_", "").lower()
            config_dict[config_key] = value
    
    return Config(**config_dict)


def load_config_from_yaml(yaml_path: str) -> Config:
    """Load configuration from a specific YAML file."""
    return get_config(yaml_path)


# Convenience function for accessing config
def get_default_config() -> Config:
    """Get default configuration."""
    return get_config()
