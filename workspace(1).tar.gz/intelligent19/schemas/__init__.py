# Core Schemas for INTELLIGENT19 V5

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


class ExecutionLevel(str, Enum):
    """Execution levels for query processing."""
    L0 = "L0"  # Deterministic
    L1 = "L1"  # Fast RAG
    L2 = "L2"  # Analytical RAG
    L3 = "L3"  # Cognitive Research


class KnowledgeType(str, Enum):
    """Types of knowledge objects."""
    DOCUMENT = "document"
    FACT = "fact"
    ENTITY = "entity"
    RELATIONSHIP = "relationship"
    EVENT = "event"
    PROCEDURE = "procedure"
    METADATA = "metadata"


class TrustLevel(str, Enum):
    """Trust levels for knowledge sources."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERIFIED = "verified"


class ClaimType(str, Enum):
    """Types of claims."""
    FACTUAL = "factual"
    OPINION = "opinion"
    INFERENCE = "inference"
    HYPOTHESIS = "hypothesis"
    CONCLUSION = "conclusion"


class VerificationStatus(str, Enum):
    """Verification status for claims."""
    PENDING = "pending"
    SUPPORTED = "supported"
    WEAKLY_SUPPORTED = "weakly_supported"
    UNCERTAIN = "uncertain"
    CONTRADICTED = "contradicted"
    REFUTED = "refuted"


class RelationshipType(str, Enum):
    """Relationship types in evidence graph."""
    SUPPORTS = "SUPPORTS"
    CONTRADICTS = "CONTRADICTS"
    DERIVED_FROM = "DERIVED_FROM"
    MENTIONS = "MENTIONS"
    ABOUT = "ABOUT"
    VALID_DURING = "VALID_DURING"
    SUPERSEDES = "SUPERSEDES"
    RELATED_TO = "RELATED_TO"
    CAUSED_BY = "CAUSED_BY"


class TaskState(str, Enum):
    """Task execution states."""
    RECEIVED = "received"
    ANALYZING = "analyzing"
    PLANNING = "planning"
    RETRIEVING = "retrieving"
    FUSING = "fusing"
    REASONING = "reasoning"
    VERIFYING = "verifying"
    RECOVERING = "recovering"
    COMPLETED = "completed"
    FAILED = "failed"
    DEGRADED = "degraded"


class IntentType(str, Enum):
    """Query intent types."""
    LOOKUP = "lookup"
    DEFINITION = "definition"
    EXPLANATION = "explanation"
    COMPARISON = "comparison"
    CAUSAL = "causal"
    TEMPORAL = "temporal"
    PROCEDURAL = "procedural"
    ANALYTICAL = "analytical"
    CREATIVE = "creative"
    VERIFICATION = "verification"


# ============================================================================
# CANONICAL KNOWLEDGE OBJECT
# ============================================================================

class CanonicalKnowledgeObject(BaseModel):
    """
    Canonical representation of all knowledge in the system.
    All storage backends (vector, graph, lexical) are derived projections.
    """
    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str
    source_id: str
    content_hash: str
    
    entity_ids: list[str] = Field(default_factory=list)
    
    content: str
    knowledge_type: KnowledgeType
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None
    
    authority_score: float = Field(ge=0.0, le=1.0, default=0.5)
    trust_level: TrustLevel = TrustLevel.MEDIUM
    
    version: int = 1
    embedding_version: Optional[str] = None
    
    provenance_id: Optional[str] = None
    
    metadata: dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        frozen = True


# ============================================================================
# QUERY SCHEMAS
# ============================================================================

class QueryAnalysis(BaseModel):
    """
    Output from query intelligence module.
    Used for routing and execution level determination.
    """
    intent: IntentType
    domain: str
    entities: list[str] = Field(default_factory=list)
    complexity: float = Field(ge=0.0, le=1.0, default=0.0)
    ambiguity: float = Field(ge=0.0, le=1.0, default=0.0)
    risk: float = Field(ge=0.0, le=1.0, default=0.0)
    time_sensitive: bool = False
    requires_exact_match: bool = False
    requires_graph: bool = False
    requires_memory: bool = False
    requires_external_data: bool = False
    requires_multi_hop: bool = False
    requires_verification: bool = True
    execution_level: ExecutionLevel = ExecutionLevel.L1
    
    confidence: float = Field(ge=0.0, le=1.0, default=0.0)


class RetrievalQuery(BaseModel):
    """Normalized query for retrieval operations."""
    query_id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str
    original_query: str
    expanded_queries: list[str] = Field(default_factory=list)
    entities: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    time_range: Optional[tuple[datetime, datetime]] = None
    limit: int = 20
    execution_level: ExecutionLevel = ExecutionLevel.L1


# ============================================================================
# RETRIEVAL SCHEMAS
# ============================================================================

class RetrievalResult(BaseModel):
    """Result from a single retriever."""
    result_id: str = Field(default_factory=lambda: str(uuid4()))
    knowledge_object_id: str
    score: float
    rank: int
    retriever_type: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class FusedResult(BaseModel):
    """Result after fusion of multiple retrievers."""
    result_id: str = Field(default_factory=lambda: str(uuid4()))
    knowledge_object_id: str
    fused_score: float
    rank: int
    component_scores: dict[str, float] = Field(default_factory=dict)
    rrf_score: float = 0.0
    metadata: dict[str, Any] = Field(default_factory=dict)


# ============================================================================
# EVIDENCE SCHEMAS
# ============================================================================

class Evidence(BaseModel):
    """Evidence object supporting or contradicting claims."""
    evidence_id: str = Field(default_factory=lambda: str(uuid4()))
    knowledge_object_id: str
    text_span: str
    start_offset: int
    end_offset: int
    relevance_score: float
    authority_score: float
    freshness_score: float
    provenance_id: str


class Claim(BaseModel):
    """
    Claim extracted from generated answer.
    Must be verified against evidence.
    """
    claim_id: str = Field(default_factory=lambda: str(uuid4()))
    text: str
    claim_type: ClaimType
    evidence_ids: list[str] = Field(default_factory=list)
    support_score: float = 0.0
    contradiction_score: float = 0.0
    confidence: float = 0.0
    verification_status: VerificationStatus = VerificationStatus.PENDING
    temporal_validity: Optional[tuple[datetime, datetime]] = None


class Contradiction(BaseModel):
    """Detected contradiction between evidence/claims."""
    contradiction_id: str = Field(default_factory=lambda: str(uuid4()))
    element_a_id: str
    element_b_id: str
    relationship: str = "CONTRADICTS"
    severity: float = Field(ge=0.0, le=1.0)
    resolution: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0)
    explanation: Optional[str] = None


# ============================================================================
# PROVENANCE SCHEMAS
# ============================================================================

class Provenance(BaseModel):
    """Provenance tracking for knowledge objects."""
    provenance_id: str = Field(default_factory=lambda: str(uuid4()))
    source_type: str  # document, database, api, manual, etc.
    source_uri: Optional[str] = None
    source_name: str
    ingested_at: datetime = Field(default_factory=datetime.utcnow)
    ingested_by: str
    processing_pipeline: list[str] = Field(default_factory=list)
    transformations: list[dict[str, Any]] = Field(default_factory=list)
    chain_of_custody: list[dict[str, Any]] = Field(default_factory=list)


# ============================================================================
# MEMORY SCHEMAS
# ============================================================================

class MemoryType(str, Enum):
    """Types of memory layers."""
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    STRATEGIC = "strategic"


class MemoryEntry(BaseModel):
    """Base memory entry."""
    memory_id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str
    memory_type: MemoryType
    content: str
    importance: float = Field(ge=0.0, le=1.0, default=0.5)
    confidence: float = Field(ge=0.0, le=1.0, default=0.5)
    access_count: int = 0
    last_accessed: datetime = Field(default_factory=datetime.utcnow)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    decay_rate: float = Field(ge=0.0, le=1.0, default=0.01)
    validation_status: str = "pending"
    contradiction_count: int = 0
    source_quality: float = Field(ge=0.0, le=1.0, default=0.5)


# ============================================================================
# HYPOTHESIS SCHEMAS
# ============================================================================

class Hypothesis(BaseModel):
    """Hypothesis for analytical reasoning."""
    hypothesis_id: str = Field(default_factory=lambda: str(uuid4()))
    statement: str
    prior_probability: float = Field(ge=0.0, le=1.0, default=0.5)
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    contradicting_evidence_ids: list[str] = Field(default_factory=list)
    posterior_score: float = Field(ge=0.0, le=1.0, default=0.5)
    status: VerificationStatus = VerificationStatus.PENDING
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# TASK & ORCHESTRATION SCHEMAS
# ============================================================================

class Task(BaseModel):
    """Task in the orchestration system."""
    task_id: str = Field(default_factory=lambda: str(uuid4()))
    request_id: str
    tenant_id: str
    state: TaskState = TaskState.RECEIVED
    execution_level: ExecutionLevel = ExecutionLevel.L1
    query_analysis: Optional[QueryAnalysis] = None
    plan: Optional[list[dict[str, Any]]] = None
    results: dict[str, Any] = Field(default_factory=dict)
    errors: list[dict[str, Any]] = Field(default_factory=list)
    retries: int = 0
    max_retries: int = 3
    created_at: datetime = Field(default_factory=datetime.utcnow)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    budget: Optional[Budget] = None


class Budget(BaseModel):
    """Resource budget for task execution."""
    max_runtime_ms: int = 15000
    max_llm_calls: int = 8
    max_tool_calls: int = 10
    max_retrieval_rounds: int = 3
    max_tokens: int = 12000
    max_cost: float = 0.05
    
    used_runtime_ms: int = 0
    used_llm_calls: int = 0
    used_tool_calls: int = 0
    used_retrieval_rounds: int = 0
    used_tokens: int = 0
    used_cost: float = 0.0
    
    def is_exceeded(self) -> bool:
        """Check if any budget limit is exceeded."""
        return (
            self.used_runtime_ms > self.max_runtime_ms or
            self.used_llm_calls > self.max_llm_calls or
            self.used_tool_calls > self.max_tool_calls or
            self.used_retrieval_rounds > self.max_retrieval_rounds or
            self.used_tokens > self.max_tokens or
            self.used_cost > self.max_cost
        )


# ============================================================================
# RESPONSE SCHEMAS
# ============================================================================

class ConfidenceVector(BaseModel):
    """Multi-dimensional confidence scores."""
    retrieval: float = Field(ge=0.0, le=1.0, default=0.0)
    evidence: float = Field(ge=0.0, le=1.0, default=0.0)
    source: float = Field(ge=0.0, le=1.0, default=0.0)
    reasoning: float = Field(ge=0.0, le=1.0, default=0.0)
    temporal: float = Field(ge=0.0, le=1.0, default=0.0)
    consistency: float = Field(ge=0.0, le=1.0, default=0.0)
    verification: float = Field(ge=0.0, le=1.0, default=0.0)


class Response(BaseModel):
    """Final response from the system."""
    response_id: str = Field(default_factory=lambda: str(uuid4()))
    request_id: str
    tenant_id: str
    answer: str
    claims: list[Claim] = Field(default_factory=list)
    evidence: list[Evidence] = Field(default_factory=list)
    confidence: ConfidenceVector = Field(default_factory=ConfidenceVector)
    execution_level: ExecutionLevel = ExecutionLevel.L1
    degraded_mode: bool = False
    verification_status: VerificationStatus = VerificationStatus.PENDING
    sources: list[str] = Field(default_factory=list)
    latency_ms: int = 0
    llm_calls: int = 0
    tool_calls: int = 0
    retrieval_rounds: int = 0
    recovery_count: int = 0
    warnings: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# TOOL SCHEMAS
# ============================================================================

class ToolPermission(str, Enum):
    """Tool permission levels."""
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


class RiskLevel(str, Enum):
    """Tool risk levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ToolDefinition(BaseModel):
    """Definition of an available tool."""
    name: str
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    permission: ToolPermission = ToolPermission.ALLOW
    risk_level: RiskLevel = RiskLevel.LOW
    timeout_ms: int = 5000
    retry_policy: dict[str, Any] = Field(default_factory=dict)
    budget_cost: float = 0.01


class ToolCall(BaseModel):
    """Record of a tool invocation."""
    call_id: str = Field(default_factory=lambda: str(uuid4()))
    tool_name: str
    arguments: dict[str, Any]
    result: Optional[Any] = None
    error: Optional[str] = None
    duration_ms: int = 0
    success: bool = False
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# OBSERVABILITY SCHEMAS
# ============================================================================

class TraceEvent(BaseModel):
    """Event for distributed tracing."""
    event_id: str = Field(default_factory=lambda: str(uuid4()))
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    event_type: str
    component: str
    operation: str
    tenant_id: str
    request_id: Optional[str] = None
    task_id: Optional[str] = None
    status: str = "success"
    error: Optional[str] = None
    duration_ms: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class HealthStatus(BaseModel):
    """Health check status for a component."""
    component: str
    status: str  # healthy, degraded, unhealthy
    message: Optional[str] = None
    latency_ms: Optional[int] = None
    last_check: datetime = Field(default_factory=datetime.utcnow)


class SystemHealth(BaseModel):
    """Overall system health."""
    overall: str  # healthy, degraded, unhealthy
    components: dict[str, HealthStatus] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# EVALUATION SCHEMAS
# ============================================================================

class RetrievalMetrics(BaseModel):
    """Metrics for retrieval evaluation."""
    recall_at_k: dict[int, float] = Field(default_factory=dict)
    precision_at_k: dict[int, float] = Field(default_factory=dict)
    mrr: float = 0.0
    ndcg: float = 0.0
    map_score: float = 0.0


class ReasoningMetrics(BaseModel):
    """Metrics for reasoning evaluation."""
    correctness: float = 0.0
    groundedness: float = 0.0
    faithfulness: float = 0.0
    hallucination_rate: float = 0.0
    contradiction_resolution_rate: float = 0.0
    multi_hop_accuracy: float = 0.0


class BenchmarkResult(BaseModel):
    """Result from benchmark execution."""
    benchmark_name: str
    dataset: str
    total_samples: int
    passed: int
    failed: int
    metrics: dict[str, float] = Field(default_factory=dict)
    latency_p50_ms: float = 0.0
    latency_p95_ms: float = 0.0
    latency_p99_ms: float = 0.0
    failure_rate: float = 0.0
    cost_per_request: float = 0.0
    executed_at: datetime = Field(default_factory=datetime.utcnow)
